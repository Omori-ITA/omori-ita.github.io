//=============================================================================
// TDS Custom Battle Action Text
// Version: 1.0
//=============================================================================
// Add to Imported List
var Imported = Imported || {} ; Imported.TDS_CustomBattleActionText = true;
// Initialize Alias Object
var _TDS_ = _TDS_ || {} ; _TDS_.CustomBattleActionText = _TDS_.CustomBattleActionText || {};
//=============================================================================
 /*:
 * @plugindesc
 * This plugins allows you to set customized messages for actions.
 *
 * @author TDS
 */
//=============================================================================


//=============================================================================
// ** Window_BattleLog
//-----------------------------------------------------------------------------
// The window for displaying battle progress. No frame is displayed, but it is
// handled as a window for convenience.
//=============================================================================
// Alias Listing
//=============================================================================
_TDS_.CustomBattleActionText.Window_BattleLog_displayAction         = Window_BattleLog.prototype.displayAction;
_TDS_.CustomBattleActionText.Window_BattleLog_displayActionResults  = Window_BattleLog.prototype.displayActionResults;
//=============================================================================
// * Make Custom Action Text
//=============================================================================
Window_BattleLog.prototype.makeCustomActionText = function(subject, target, item) {
  var user          = subject;
  var result        = target.result();
  var hit           = result.isHit();
  var success       = result.success;
  var critical      = result.critical;
  var missed        = result.missed;
  var evaded        = result.evaded;
  var hpDam         = result.hpDamage;
  var mpDam         = result.mpDamage;
  var tpDam         = result.tpDamage;
  var addedStates   = result.addedStates;
  var removedStates = result.removedStates;
  var strongHit     = result.elementStrong;
  var weakHit       = result.elementWeak;
  var text = '';
  var type = item.meta.BattleLogType.toUpperCase();
  var switches = $gameSwitches;
  var unitLowestIndex = target.friendsUnit().getLowestIndexMember();


  function parseNoEffectEmotion(tname, em) {
    if(em.toLowerCase().contains("paura")) {
      if(tname === "OMORI") {return "OMORI non può avere PAURA!\r\n"};
      return target.name() + " non può avere più PAURA di così!\r\n";
    }
    let finalString = `${tname} non può essere ${em} di così!\r\n`;
    if(finalString.length >= 30) {
      let voinIndex = 0;
      for(let i = 30; i >= 0; i--) {
        if(finalString[i] === " ") {
          voinIndex = i;
          break;
        }
      }
      finalString = [finalString.slice(0, voinIndex).trim(), "\r\n", finalString.slice(voinIndex).trimLeft()].join('');
    }
    return finalString;
  }

  function parseNoStateChange(tname,stat,hl) {
    let noStateChangeText = `${stat} di ${tname}\r\nnon può essere ${hl}\r\n`; // TARGET NAME - STAT - HIGHER/LOWER
    return noStateChangeText
  }

  // Type case
//OMORI//
if (hpDam != 0) {
  var hpDamageText = target.name() + ' riceve ' + hpDam + ' di danno!';
  if (strongHit) {
    hpDamageText = '...Bel colpo!\r\n' + hpDamageText;
  } else if (weakHit) {
    hpDamageText = '...Colpo fiacco.\r\n' + hpDamageText;
  }
} else if (result.isHit() === true) {
  var hpDamageText = "L'attacco di " + user.name() + "\r\nnon ha avuto effetto.";
} else {
  var hpDamageText = "L'attacco di " + user.name() + "\r\nnon va a segno!";
}

if (critical) {
    hpDamageText = 'COLPO CRITICO!\r\n' + hpDamageText;
}

if (mpDam > 0) {
  var mpDamageText = target.name() + ' perde ' + mpDam + ' di SUCCO...';
  hpDamageText = hpDamageText + "\r\n" + mpDamageText;
} else {
  var mpDamageText = '';
}

  switch (type) {
  case 'BLANK': // ATTACK
    text = '...';
    break;

  case 'ATTACK': // ATTACK
    text = user.name() + ' attacca ' + target.name() + '!\r\n';
    text += hpDamageText;
    break;

  case 'MULTIHIT':
    text = user.name() + "infligge danni pesanti!\r\n";
    break;

  case 'OBSERVE': // OBSERVE
    text = user.name() + ' concentra la sua vista e osserva\r\n';
    text += target.name() + '!';
    break;

  case 'OBSERVE TARGET': // OBSERVE TARGET
    //text = user.name() + " observes " + target.name() + ".\r\n";
    text = target.name() + ' ha gli occhi puntati su\r\n';
    text += user.name() + '!';
    break;

  case 'OBSERVE ALL': // OBSERVE TARGET
    //text = user.name() + " observes " + target.name() + ".\r\n";
    text = user.name() + ' concentra la sua visione ed osserva\r\n';
    text += target.name() + '!';
    text = target.name() + ' ha gli occhi puntati su tutti!';
    break;

  case 'SAD POEM':  // SAD POEM
    text = user.name() + ' legge una poesia triste.\r\n';
    if(!target._noEffectMessage) {
      if(target.isStateAffected(12)) {text += target.name() + ' è in preda alla MISERIA...';}
      else if(target.isStateAffected(11)) {text += target.name() + ' si DEPRIME..';}
      else if(target.isStateAffected(10)) {text += target.name() + ' diventa TRISTE.';}
    }
    else {text += parseNoEffectEmotion(target.name(), "più TRISTE")};
    break;

  case 'STAB': // STAB
    text = user.name() + ' accoltella ' + target.name() + '.\r\n';
    text += hpDamageText;
    break;

  case 'TRICK':  // TRICK
    text = user.name() + ' inganna ' + target.name() + '.\r\n';
    if(target.isEmotionAffected("happy")) {
      if(!target._noStateMessage) {text += "La VELOCITÀ di" + target.name() + ' cala!\r\n';}
      else {text += parseNoStateChange(target.name(), "LA VELOCITÀ", "più bassa!")};
    }
    text += hpDamageText;
    break;

  case 'SHUN': // SHUN
    text = user.name() + ' trascura ' + target.name() + '.\r\n';
    if(target.isEmotionAffected("sad")) {
      if(!target._noStateMessage) {text += "La DIFESA di " + target.name() + ' cala.\r\n';}
      else {text += parseNoStateChange(target.name(), "LA DIFESA", "più bassa!")};
    }
    text += hpDamageText;
    break;

  case 'MOCK': // MOCK
    text = user.name() + ' insulta ' + target.name() + '.\r\n';
    text += hpDamageText;
    break;

  case 'HACKAWAY':  // Hack Away
    text = user.name() + ' colpisce selvaggiamente\r\na caso con il suo coltello!';
    break;

  case 'PICK POCKET': //Pick Pocket
    text = user.name() + ' prova a prendere un oggetto!\r\n';
    text += 'da ' + target.name();
    break;

  case 'BREAD SLICE': //Bread Slice
    text = user.name() + ' affetta ' + target.name() + '!\r\n';
    text += hpDamageText;
    break;

  case 'HIDE': // Hide
    text = user.name() + " si nasconde nell'ambiente circostante... ";
    break;

  case 'QUICK ATTACK': // Quick Attack
    text = user.name() + ' salta addosso a ' + target.name() + '!\r\n';
    text += hpDamageText;
    break;

  case 'EXPLOIT HAPPY': //Exploit Happy
    text = user.name() + ' sfrutta la FELICITÀ\r\ndi ' + target.name() + '!\r\n';
    text += hpDamageText;
    break;

  case 'EXPLOIT SAD': // Exploit Sad
    text = user.name() + ' sfrutta la TRISTEZZA\r\ndi ' + target.name() + '!\r\n';
    text += 'sadness!\r\n';
    text += hpDamageText;
    break;

  case 'EXPLOIT ANGRY': // Exploit Angry
    text = user.name() + ' sfrutta la RABBIA\r\ndi ' + target.name() + '!\r\n';
    text += 'anger!\r\n';
    text += hpDamageText;
    break;

  case 'EXPLOIT EMOTION': // Exploit Emotion
    text = user.name() + " sfrutta le EMOZIONI\r\ndi " + target.name() + "!";
    if(text.length >= 34) {
      text = user.name() + ' sfrutta le EMOZIONI di ' ;
      text += target.name() + '!\r\n';
    }
    else {text += "\r\n"};
    text += hpDamageText;
    break;

  case 'FINAL STRIKE': // Final Strike
    text = user.name() + ' rilascia il suo attacco definitivo!';
    break;

  case 'TRUTH': // PAINFUL TRUTH
    text = user.name() + ' sussurra qualcosa a\r\n';
    text += target.name() + '.\r\n';
    text += hpDamageText + "\r\n";
    if(!target._noEffectMessage) {
      text += target.name() + " diventa TRISTE.\r\n";
    }
    else {text += parseNoEffectEmotion(target.name(), "più TRISTE")};
    if(user.isStateAffected(12)) {text += user.name() + " è in preda alla MISERIA...";}
    else if(user.isStateAffected(11)) {text += user.name() + " si DEPRIME..";}
    else if(user.isStateAffected(10)) {text += user.name() + " diventa TRISTE.";}
    break;

  case 'ATTACK AGAIN':  // ATTACK AGAIN 2
    text = user.name() + ' attacca di nuovo!\r\n';
    text += hpDamageText;
    break;

  case 'TRIP':  // TRIP
    text = user.name() + ' fa lo sgambetto\r\na ' + target.name() + '!\r\n';
    if(!target._noStateMessage) {text += "La VELOCITÀ di " + target.name() + ' cala!\r\n';}
    else {text += parseNoStateChange(target.name(), "LA VELOCITÀ", "più bassa")};
    text += hpDamageText;
    break;

    case 'TRIP 2':  // TRIP 2
      text = user.name() + ' fa lo sgambetto\r\na ' + target.name() + '!\r\n';
      if(!target._noStateMessage) {text += "La VELOCITÀ di " + target.name() + ' cala!\r\n';}
      else {text += parseNoStateChange(target.name(), "LA VELOCITÀ", "più bassa!")}
      if(!target._noEffectMessage) {text += target.name() + ' diventa TRISTE.\r\n';}
      else {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
      text += hpDamageText;
      break;

  case 'STARE': // STARE
    text = user.name() + ' fissa ' + target.name() + '.\r\n';
    text += target.name() + ' si sente a disagio.';
    break;

  case 'RELEASE ENERGY':  // RELEASE ENERGY
    text = user.name() + ' e i suoi amici si riuniscono e\r\n';
    text += 'usano il loro attacco definitivo!';
    break;

  case 'VERTIGO': // OMORI VERTIGO
    if(target.index() <= unitLowestIndex) {
      text = user.name() + ' fa perdere l\'equilibrio ai nemici!\r\n';
      text += 'L\'ATTACCO di tutti i nemici cala!\r\n';
    }
    text += hpDamageText;
    break;

  case 'CRIPPLE': // OMORI CRIPPLE
    if(target.index() <= unitLowestIndex) {
      text = user.name() + ' paralizza i nemici!\r\n';
      text += "La VELOCITÀ di tutti i nemici cala.\r\n";
    }
    text += hpDamageText;
    break;

  case 'SUFFOCATE': // OMORI SUFFOCATE
    if(target.index() <= unitLowestIndex) {
      text = user.name() + ' soffoca i nemici!\r\n';
      text += 'Tutti i nemici si sentono mancare il respiro.\r\n';
      text += "La DIFESA di tutti i nemici cala.\r\n";
    }
    text += hpDamageText;
    break;

  //AUBREY//
  case 'PEP TALK':  // PEP TALK
    text = user.name() + ' incoraggia ' + target.name() + '!\r\n';
    if(!target._noEffectMessage) {
      if(target.isStateAffected(8)) {text += target.name() + ' è in preda alla MANIA!!!';}
      else if(target.isStateAffected(7)) {text += target.name() + ' è in preda all\'ESTASI!!';}
      else if(target.isStateAffected(6)) {text += target.name() + ' diventa FELICE!';}
    }
    else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
    break;

  case 'TEAM SPIRIT':  // TEAM SPIRIT
    text = user.name() + ' tifa per ' + target.name() + '!\r\n';
    if(!target._noEffectMessage) {
      if(target.isStateAffected(8)) {text += target.name() + ' è in preda alla MANIA!!!\r\n';}
      else if(target.isStateAffected(7)) {text += target.name() + ' è in preda all\'ESTASI!!\r\n';}
      else if(target.isStateAffected(6)) {text += target.name() + ' diventa FELICE!\r\n';}
    }
    else {text += parseNoEffectEmotion(target.name(), "più FELICE\r\n")}

    if(!user._noEffectMessage) {
      if(user.isStateAffected(8)) {text += user.name() + ' è in preda alla MANIA!!!';}
      else if(user.isStateAffected(7)) {text += user.name() + ' è in preda all\'ESTASI!!';}
      else if(user.isStateAffected(6)) {text += user.name() + ' diventa FELICE!';}
    }
    else {text += parseNoEffectEmotion(user.name(), "più FELICE\r\n")}
    break;

  case 'HEADBUTT':  // HEADBUTT
    text = user.name() + ' dà una testata\r\na ' + target.name() + '!\r\n';
    text += hpDamageText;
    break;

  case 'HOMERUN': // Homerun
    text = user.name() + ' tira ' + target.name() + '\r\n';
    text += 'fuoricampo!\r\n';
    text += hpDamageText;
    break;

  case 'THROW': // Wind-up Throw
    text = user.name() + ' lancia la sua arma!';
    break;

  case 'POWER HIT': //Power Hit
    text = user.name() + ' sfascia ' + target.name() + '!\r\n';
    if(!target._noStateMessage) {text += "La DIFESA di " + target.name() + ' cala.\r\n';}
    else {text += parseNoStateChange(target.name(), "LA DIFESA", "più bassa!")}
    text += hpDamageText;
    break;

  case 'LAST RESORT': // Last Resort
    text = user.name() + ' colpisce ' + target.name() + '\r\n';
    text += 'con tutta la sua forza!\r\n';
    text += hpDamageText;
    break;

  case 'COUNTER ATTACK': // Counter Attack
    text = user.name() + ' prepara la sua mazza!';
    break;

  case 'COUNTER HEADBUTT': // Counter Headbutt
    text = user.name() + ' prepara la sua testa!';
    break;

  case 'COUNTER ANGRY': //Counter Angry
    text = user.name() + ' è all\'allerta!';
    break;

  case 'LOOK OMORI 1':  // Look at Omori 2
    text = 'OMORI non ha notato ' + user.name() + ', quindi\r\n';
    text += user.name() + ' attacca di nuovo!\r\n';
    text += hpDamageText;
    break;

  case 'LOOK OMORI 2': // Look at Omori 2
    text = 'OMORI non ha ancora notato ' + user.name() + ', quindi\r\n';
    text += user.name() + ' attacca più forte!\r\n';
    text += hpDamageText;
    break;

  case 'LOOK OMORI 3': // Look at Omori 3
    text = 'OMORI finalmente nota ' + user.name() + '!\r\n';
    text += user.name() + ' colpisce entusiasta con la sua mazza!\r\n';
    text += hpDamageText;
    break;

  case 'LOOK KEL 1':  // Look at Kel 1
    text = 'KEL provoca AUBREY!\r\n';
    text += target.name() + " si ARRABBIA!";
    break;

  case 'LOOK KEL 2': // Look at Kel 2
   text = 'KEL provoca AUBREY!\r\n';
   text += 'L\'ATTACCO di KEL e AUBREY aumenta!\r\n';
   var AUBREY = $gameActors.actor(2);
   var KEL = $gameActors.actor(3);
   if(AUBREY.isStateAffected(14) && KEL.isStateAffected(14)) {text += 'KEL e AUBREY sono ARRABBIATI!';}
   else if(AUBREY.isStateAffected(14) && KEL.isStateAffected(15)) {
    text += 'KEL è in preda alla FURIA!!\r\n';
    text += 'AUBREY diventa ARRABBIATA!';
   }
   else if(AUBREY.isStateAffected(15) && KEL.isStateAffected(14)) {
    text += 'KEL diventa ARRABBIATO!\r\n';
    text += 'AUBREY è in preda alla FURIA!!';
   }
   else if(AUBREY.isStateAffected(15) && KEL.isStateAffected(15)) {text += 'KEL e AUBREY sono in preda alla FURIA!!';}
   else {text += 'KEL e AUBREY sono ARRABBIATI!';}
   break;

  case 'LOOK HERO':  // LOOK AT HERO 1
    text = 'HERO dice ad AUBREY di concentrarsi!\r\n';
    if(target.isStateAffected(6)) {text += target.name() + " diventa FELICE!\r\n"}
    else if(target.isStateAffected(7)) {text += target.name() + " è in preda all'ESTASI!!\r\n"}
    text += "La DIFESA di " + user.name() + ' aumenta!!';
    break;

  case 'LOOK HERO 2': // LOOK AT HERO 2
    text = 'HERO tifa per AUBREY!\r\n';
    text += 'La DIFESA di AUBREY è aumentata!!\r\n';
    if(target.isStateAffected(6)) {text += target.name() + " diventa FELICE!\r\n"}
    else if(target.isStateAffected(7)) {text += target.name() + " è in preda all'ESTASI!!\r\n"}
    if(!!$gameTemp._statsState[0]) {
      var absHp = Math.abs($gameTemp._statsState[0] - $gameActors.actor(2).hp);
      if(absHp > 0) {text += `AUBREY recupera ${absHp} di VITA!\r\n`;}
    }
    if(!!$gameTemp._statsState[1]) {
      var absMp = Math.abs($gameTemp._statsState[1] - $gameActors.actor(2).mp);
      if(absMp > 0) {text += `AUBREY recupera ${absMp} di SUCCO...`;}
    }
    $gameTemp._statsState = undefined;
    break;

  case 'TWIRL': // ATTACK
    text = user.name() + ' attacca ' + target.name() + '!\r\n';
    text += hpDamageText;
    break;

  //KEL//
    case 'ANNOY':  // ANNOY
      text = user.name() + ' infastidisce ' + target.name() + '!\r\n';
      if(!target._noEffectMessage) {
        if(target.isStateAffected(14)) {text += target.name() + ' si ARRABBIA!';}
        else if(target.isStateAffected(15)) {text += target.name() + ' è in preda alla FURIA!!';}
        else if(target.isStateAffected(16)) {text += target.name() + ' è in preda all\'IRA!!!';}
      }
      else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
      break;

    case 'REBOUND':  // REBOUND
      text = "La palla di" + user.name() + 'rimbalza dappertutto!';
      break;

    case 'FLEX':  // FLEX
      text = user.name() + ' flette i suoi muscoli\r\ne si sente un campione!\r\n';
      text += "La PRECISIONE di\r\n" + user.name() + " aumenta!\r\n"
      break;

    case 'JUICE ME': // JUICE ME
      text = user.name() + ' passa il COCCO a ' + target.name() + '!\r\n'
      var absMp = Math.abs(mpDam);
      if(absMp > 0) {
        text += `${target.name()} recupera ${absMp} di SUCCO...\r\n`
      }
      text += hpDamageText;
      break;

    case 'RALLY': // RALLY
      text = user.name() + ' fa gasare tutti!\r\n';
      if(user.isStateAffected(7)) {text += user.name() + " è in preda all'ESTASI!!\r\n"}
      else if(user.isStateAffected(6)) {text += user.name() + " diventa FELICE!\r\n"}
      text += "Tutti guadagnano ENERGIA!\r\n"
      for(let actor of $gameParty.members()) {
        if(actor.name() === "KEL") {continue;}
        var result = actor.result();
        if(result.mpDamage >= 0) {continue;}
        var absMp = Math.abs(result.mpDamage);
        text += `${actor.name()} recupera ${absMp} di SUCCO...\r\n`
      }
      break;

    case 'SNOWBALL': // SNOWBALL
      text = user.name() + ' lancia una PALLA DI NEVE a\r\n';
      text += target.name() + '!\r\n';
      if(!target._noEffectMessage) {text += target.name() + " diventa TRISTE.\r\n"}
      else {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
      text += hpDamageText;
      break;

    case 'TICKLE': // TICKLE
      text = user.name() + ' fa il solletico a ' + target.name() + '!\r\n'
      text += `${target.name()} abbassa la guardia!`
      break;

    case 'RICOCHET': // RICOCHET
     text = user.name() + ' fa un trucco\r\ncomplicato con la palla!\r\n';
     text += hpDamageText;
     break;

    case 'CURVEBALL': // CURVEBALL
     text = user.name() + ' lancia una palla curva...\r\n';
     text += target.name() + ' è colto alla sprovvista.\r\n';
     switch($gameTemp._randomState) {
       case 6:
         if(!target._noEffectMessage) {text += target.name() + " diventa FELICE!\r\n"}
         else {text += parseNoEffectEmotion(target.name(), "più FELICE\r\n")}
         break;
      case 14:
        if(!target._noEffectMessage) {text += target.name() + " è in preda alla RABBIA!\r\n"}
        else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
        break;
      case 10:
        if(!target._noEffectMessage) {text += target.name() + " diventa TRISTE.\r\n"}
        else {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
        break;

     }
     text += hpDamageText;
     break;

    case 'MEGAPHONE': // MEGAPHONE
      if(target.index() <= unitLowestIndex) {text = user.name() + ' corre in giro e infastidisce tutti!\r\n';}
      if(target.isStateAffected(16)) {text += target.name() + ' è in preda all\'IRA!!!\r\n'}
      else if(target.isStateAffected(15)) {text += target.name() + ' è in preda alla FURIA!!\r\n'}
      else if(target.isStateAffected(14)) {text += target.name() + ' si ARRABBIA!\r\n'}
      break;

    case 'DODGE ATTACK': // DODGE ATTACK
      text = user.name() + ' si prepara a schivare!';
      break;

    case 'DODGE ANNOY': // DODGE ANNOY
      text = user.name() + ' prende in giro i nemici!';
      break;

    case 'DODGE TAUNT': // DODGE TAUNT
      text = user.name() + ' provoca i nemici!\r\n';
      text += "La PRECISIONE di tutti i nemici cala per questo turno!"
      break;

    case 'PASS OMORI':  // KEL PASS OMORI
      text = 'OMORI era distratto e si becca\r\nuna pallonata!\r\n';
      text += 'OMORI subisce 1 danno!';
      break;

    case 'PASS OMORI 2': //KEL PASS OMORI 2
      text = 'OMORI prende la palla di KEL!\r\n';
      text += 'OMORI lancia la palla a\r\n';
      text += target.name() + '!\r\n';
      var OMORI = $gameActors.actor(1);
      if(OMORI.isStateAffected(6)) {text += "OMORI diventa FELICE!\r\n"}
      else if(OMORI.isStateAffected(7)) {text += "OMORI è in preda all'ESTASI!!\r\n"}
      text += hpDamageText;
      break;

    case 'PASS AUBREY':  // KEL PASS AUBREY
      text = 'AUBREY colpisce un fuoricampo!\r\n';
      text += hpDamageText;
      break;

    case 'PASS HERO':  // KEL PASS HERO
      if(target.index() <= unitLowestIndex) {text = user.name() + ' fa una schiacciata sui nemici!\r\n';}
      text += hpDamageText;
      break;

    case 'PASS HERO 2':  // KEL PASS HERO
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' fa una schiacciata sui nemici con stile!\r\n';
        text += "L\'ATTACCO di tutti i nemici cala!\r\n";
      }
      text += hpDamageText;
      break;

    //HERO//
    case 'MASSAGE':  // MASSAGE
      text = user.name() + ' fa un massaggio a ' + target.name() + '!\r\n';
      if(!!target.isAnyEmotionAffected(true)) {
        text += target.name() + ' si calma...';
      }
      else {text += "Non ha avuto effetto..."}
      break;

    case 'COOK':  // COOK
      text = user.name() + ' prepara un biscotto\r\nsolo per ' + target.name() + '!';
      break;

    case 'FAST FOOD': //FAST FOOD
      text = user.name() + ' prepara un pasto veloce\r\nsolo per ' + target.name() + '.';
      break;

    case 'JUICE': // JUICE
      text = user.name() + ' prepara un rinfresco\r\nsolo per ' + target.name() + '.';
      break;

    case 'SMILE':  // SMILE
      text = user.name() + ' sorride a ' + target.name() + '!\r\n';
      if(!target._noStateMessage) {text += "L\'ATTACCO DI " + target.name() + ' cala.';}
      else {text += parseNoStateChange(target.name(), "L'ATTACCO", "più basso!")}
      break;

    case 'DAZZLE':
      text = user.name() + ' sorride a ' + target.name() + '!\r\n';
      if(!target._noStateMessage) {text += "L'ATTACCO di " + target.name() + ' cala.\r\n';}
      else {text += parseNoStateChange(target.name(), "L'ATTACCO", "più basso!")}
      if(!target._noEffectMessage) {
        text += target.name() + ' diventa FELICE!';
      }
      else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
      break;
    case 'TENDERIZE': // TENDERIZE
      text = user.name() + ' massaggia intensamente\r\n';
      text += target.name() + '!\r\n';
      if(!target._noStateMessage) {text += "La DIFESA di " + target.name() + ' cala!\r\n';}
      else {text += parseNoStateChange(target.name(), "LA DIFESA", "più bassa!")}
      text += hpDamageText;
      break;

    case 'SNACK TIME':  // SNACK TIME
      text = user.name() + ' ha preparato dei biscotti per tutti!';
      break;

    case 'TEA TIME': // TEA TIME
      text = user.name() + ' porta un po\' di tè per una pausa.\r\n';
      text += target.name() + ' approfitta per un rinfresco!\r\n';
      if(result.hpDamage < 0) {
        var absHp = Math.abs(result.hpDamage);
        text += `${target.name()} recupera ${absHp} di VITA!\r\n`
      }
      if(result.mpDamage < 0) {
        var absMp = Math.abs(result.mpDamage);
        text += `${target.name()} recupera ${absMp} di SUCCO...\r\n`
      }
      break;

    case 'SPICY FOOD': // SPICY FOOD
      text = user.name() + ' prepara del cibo piccante!\r\n';
      text += hpDamageText;
      break;

    case 'SINGLE TAUNT': // SINGLE TAUNT
      text = user.name() + ' attira l\'attenzione di' + target.name() + '\'s\r\n';
      text += '.';
      break;

    case 'TAUNT':  // TAUNT
      text = user.name() + ' attira l\'attenzione del nemico.';
      break;

    case 'SUPER TAUNT': // SUPER TAUNT
      text = user.name() + ' attira l\'attenzione del nemico.\r\n';
      text += user.name() + ' si prepara per bloccare gli attacchi.';
      break;

    case 'ENCHANT':  // ENCHANT
      text = user.name() + ' attira l\'attenzione del nemico\r\n';
      text += 'con un sorriso.\r\n';
      if(!target._noEffectMessage) {text += target.name() + " diventa FELICE!";}
      else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
      break;

    case 'MENDING': //MENDING
      text = user.name() + ' fa da catering a ' + target.name() + '.\r\n';
      text += user.name() + ' ora è lo chef personale\r\ndi ' + target.name() + '!';
      break;

    case 'SHARE FOOD': //SHARE FOOD
      if(target.name() !== user.name()) {
        text = user.name() + ' condivide del cibo con ' + target.name() + '!'
      }
      break;

    case 'CALL OMORI':  // CALL OMORI
      text = user.name() + ' manda un segnale ad OMORI!\r\n';
      if(!!$gameTemp._statsState[0]) {
        var absHp = Math.abs($gameTemp._statsState[0] - $gameActors.actor(1).hp);
        if(absHp > 0) {text += `OMORI recupera ${absHp} di VITA!\r\n`;}
      }
      if(!!$gameTemp._statsState[1]) {
        var absMp = Math.abs($gameTemp._statsState[1] - $gameActors.actor(1).mp);
        if(absMp > 0) {text += `OMORI recupera ${absMp} di SUCCO...`;}
      }
      $gameTemp._statsState = undefined;
      break;

    case 'CALL KEL':  // CALL KEL
      text = user.name() + ' fa gasare KEL!\r\n';
      if(!!$gameTemp._statsState[0]) {
        var absHp = Math.abs($gameTemp._statsState[0] - $gameActors.actor(3).hp);
        if(absHp > 0) {text += `KEL recupera ${absHp} di VITA!\r\n`;}
      }
      if(!!$gameTemp._statsState[1]) {
        var absMp = Math.abs($gameTemp._statsState[1] - $gameActors.actor(3).mp);
        if(absMp > 0) {text += `KEL recupera ${absMp} di SUCCO...`;}
      }
      break;

    case 'CALL AUBREY':  // CALL AUBREY
      text = user.name() + ' incoraggia AUBREY!\r\n';
      if(!!$gameTemp._statsState[0]) {
        var absHp = Math.abs($gameTemp._statsState[0] - $gameActors.actor(2).hp);
        if(absHp > 0) {text += `AUBREY recupera ${absHp} di VITA!\r\n`;}
      }
      if(!!$gameTemp._statsState[1]) {
        var absMp = Math.abs($gameTemp._statsState[1] - $gameActors.actor(2).mp);
        if(absMp > 0) {text += `AUBREY recupera ${absMp} di SUCCO...`;}
      }
      break;

    //PLAYER//
    case 'CALM DOWN':  // PLAYER CALM DOWN
      if(item.id !== 1445) {text = user.name() + ' si calma.\r\n';} // Process if Calm Down it's not broken;
      if(Math.abs(hpDam) > 0) {text += user.name() + ' recupera ' + Math.abs(hpDam) + ' di VITA!';}
      break;

    case 'FOCUS':  // PLAYER FOCUS
      text = user.name() + ' si concentra.';
      break;

    case 'PERSIST':  // PLAYER PERSIST
      text = user.name() + ' persiste.';
      break;

    case 'OVERCOME':  // PLAYER OVERCOME
      text = user.name() + ' supera.';
      break;

  //UNIVERSAL//
    case 'FIRST AID':  // FIRST AID
      text = user.name() + ' si prende cura di ' + target.name() + '!\r\n';
      text += target.name() + ' recupera ' + Math.abs(target._result.hpDamage) + ' di VITA!';
      break;

    case 'PROTECT':  // PROTECT
      text = user.name() + ' si piazza davanti a ' + target.name() + '!';
      break;

    case 'GAURD': // GAURD
      text = user.name() + ' si prepara a bloccare attacchi.';
      break;

  //FOREST BUNNY//
    case 'BUNNY ATTACK': // FOREST BUNNY ATTACK
      text = user.name() + ' mordicchia ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BUNNY NOTHING': // BUNNY DO NOTHING
      text = user.name() + ' saltella in giro!';
      break;

    case 'BE CUTE':  // BE CUTE
      text = user.name() + ' fa un occhiolino a ' + target.name() + '!\r\n';
      text += "L'ATTACCO di " + target.name() + ' cala!';
      break;

    case 'SAD EYES': //SAD EYES
      text = user.name() + ' guarda tristemente ' + target.name() + '.\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' diventa TRISTE.';}
      else {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
      break;

  //FOREST BUNNY?//
    case 'BUNNY ATTACK2': // BUNNY? ATTACK
      text = user.name() + ' mordicchia ' + target.name() + '?\r\n';
      text += hpDamageText;
      break;

    case 'BUNNY NOTHING2':  // BUNNY? DO NOTHING
      text = user.name() + ' saltella in giro?';
      break;

    case 'BUNNY CUTE2':  // BE CUTE?
      text = user.name() + ' fa un occhiolino a ' + target.name() + '?\r\n';
      text += "L'ATTACCO di " + target.name() + ' cala?';
      break;

    case 'SAD EYES2': // SAD EYES?
      text = user.name() + ' guarda tristemente ' + target.name() + '...\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' diventa TRISTE?';}
      else {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
      break;

    //SPROUT MOLE//
    case 'SPROUT ATTACK':  // SPROUT MOLE ATTACK
      text = user.name() + ' urta ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SPROUT NOTHING':  // SPROUT NOTHING
      text = user.name() + ' rotola in giro.';
      break;

    case 'RUN AROUND':  // RUN AROUND
      text = user.name() + ' corre in giro!';
      break;

    case 'HAPPY RUN AROUND': //HAPPY RUN AROUND
      text = user.name() + ' corre energeticamente!';
       break;

    //MOON BUNNY//
    case 'MOON ATTACK':  // MOON BUNNY ATTACK
      text = user.name() + ' sbatte contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MOON NOTHING':  // MOON BUNNY NOTHING
      text = user.name() + ' ha la testa tra le nuvole.';
      break;

    case 'BUNNY BEAM':  // BUNNY BEAM
      text = user.name() + ' spara un laser!\r\n';
      text += hpDamageText;
      break;

    //DUST BUNNY//
    case 'DUST NOTHING':  // DUST NOTHING
      text = user.name() + ' sta cercando\r\n';
      text += 'di tenersi insieme.';
      break;

    case 'DUST SCATTER':  // DUST SCATTER
      text = user.name() + ' esplode!';
      break;

    //U.F.O//
    case 'UFO ATTACK':  // UFO ATTACK
      text = user.name() + ' si schianta contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'UFO NOTHING':  // UFO NOTHING
      text = user.name() + ' sta perdendo interesse.';
      break;

    case 'STRANGE BEAM':  // STRANGE BEAM
      text = user.name() + ' emette una strana luce!\r\n';
      text += target.name() + " prova un'EMOZIONE casuale!"
      break;

    case 'ORANGE BEAM':  // ORANGE BEAM
      text = user.name() + ' spara un laser arancione!\r\n';
      text += hpDamageText;
      break;

    //VENUS FLYTRAP//
    case 'FLYTRAP ATTACK':  // FLYTRAP ATTACK
      text = user.name() + ' colpisce ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'FLYTRAP NOTHING':  // FLYTRAP NOTHING
      text = user.name() + ' sta mordendo il nulla.';
      break;

    case 'FLYTRAP CRUNCH':  // FLYTRAP
      text = user.name() + ' morde ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    //WORMHOLE//
    case 'WORM ATTACK':  // WORM ATTACK
      text = user.name() + ' schiaffeggia ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'WORM NOTHING':  // WORM NOTHING
      text = user.name() + ' ondeggia...';
      break;

    case 'OPEN WORMHOLE':  // OPEN WORMHOLE
      text = user.name() + ' apre un buco nero!';
      break;

    //MIXTAPE//
    case 'MIXTAPE ATTACK':  // MIXTAPE ATTACK
      text = user.name() + ' schiaffeggia ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MIXTAPE NOTHING':  // MIXTAPE NOTHING
      text = user.name() + ' si sta districando.';
      break;

    case 'TANGLE':  // TANGLE
      text = target.name() + ' aggroviglia ' + user.name() + '!\r\n';
      text += "La VELOCITÀ di " + target.name() + ' cala!';
      break;

    //DIAL-UP//
    case 'DIAL ATTACK':  // DIAL ATTACK
      text = user.name() + ' è lento.\r\n';
      var pronumn = target.name() === "AUBREY" ? "stessa" : "stesso";
      text += `${target.name()} fa male a sé ${pronumn}per la frustrazione!\r\n`;
      text += hpDamageText;
      break;

    case 'DIAL NOTHING':  // DIAL NOTHING
      text = user.name() + ' è in buffering...';
      break;

    case 'DIAL SLOW':  // DIAL SLOW
      text = user.name() + ' ralleeeeenta.\r\n';
      text += 'La VELOCITÀ di tutti cala!';
      break;

    //DOOMBOX//
    case 'DOOM ATTACK':  // DOOM ATTACK
      text = user.name() + ' sbatte contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'DOOM NOTHING':  // DOOM NOTHING
      text = user.name() + ' sta sintonizzando la radio.';
      break;

    case 'BLAST MUSIC':  // BLAST MUSIC
      text = user.name() + ' droppa dei beat pazzeschi!';
      break;

    //SHARKPLANE//
    case 'SHARK ATTACK':  // SHARK PLANE
      text = user.name() + ' sfonda ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SHARK NOTHING':  // SHARK NOTHING
      text = user.name() + ' si pulisce i denti.';
      break;

    case 'OVERCLOCK ENGINE':  // OVERCLOCK ENGINE
      text = user.name() + ' fa partire il motore!\r\n';
      if(!target._noStateMessage) {
        text += "La VELOCITÀ di" + user.name() + ' aumenta!';
      }
      else {text += parseNoStateChange(user.name(), "LA VELOCITÀ", "più alta!")}
      break;

    case 'SHARK CRUNCH':  // SHARK
        text = user.name() + ' morde ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

    //SNOW BUNNY//
    case 'SNOW BUNNY ATTACK':  // SNOW ATTACK
      text = user.name() + ' calcia della\r\nneve a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SNOW NOTHING':  // SNOW NOTHING
      text = user.name() + ' si sta rilassando.';
      break;

    case 'SMALL SNOWSTORM':  // SMALL SNOWSTORM
      text = user.name() + ' tira della\r\nneve a tutti,\r\n';
      text += 'causando la più piccola\'s tempesta di neve al mondo!';
      break;

    //SNOW ANGEL//
    case 'SNOW ANGEL ATTACK': //SNOW ANGEL ATTACK
      text = user.name() + ' tocca ' + target.name() + '\r\n';
      text += 'con le sue mani congelate.\r\n';
      text += hpDamageText;
      break;

    case 'UPLIFTING HYMN': //UPLIFTING HYMN
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' canta una bellissima canzone...\r\n';
        text += 'Tutti diventano FELICI!';
      }
      target._noEffectMessage = undefined;
      break;

    case 'PIERCE HEART': //PIERCE HEART
      text = user.name() + ' perfora il CUORE di ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    //SNOW PILE//
    case 'SNOW PILE ATTACK': //SNOW PILE ATTACK
      text = user.name() + ' tira della\r\nneve a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SNOW PILE NOTHING': //SNOW PILE NOTHING
      text = user.name() + ' si sente ghiacciato.';
      break;

    case 'SNOW PILE ENGULF': //SNOW PILE ENGULF
      text = user.name() + ' ricopre ' + target.name() + '\r\ndi neve!\r\n';
      text += "La VELOCITÀ di " + target.name() + ' cala!\r\n';
      text += "La DIFESA di " + target.name() + ' cala!\r\n';
      break;

    case 'SNOW PILE MORE SNOW': //SNOW PILE MORE SNOW
      text = user.name() + ' si ricopre di neve!\r\n';
      text += "L'ATTACCO di " + target.name() + '\r\naumenta!';
      text += "La DIFESA di " + target.name() + '\r\naumenta!';
      break;

    //CUPCAKE BUNNY//
    case 'CCB ATTACK': //CUP CAKE BUNNY ATTACK
      text = user.name() + ' sbatte contro ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'CCB NOTHING': //CUP CAKE BUNNY NOTHING
      text = user.name() + ' salta sul posto.';
      break;

    case 'CCB SPRINKLES': //CUP CAKE BUNNY SPRINKLES
      text = user.name() + ' ricopre ' + target.name() + '.\r\n';
      text += 'di confettini.\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' diventa FELICE!\r\n';}
      else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
      text += "Le STATISTICHE di " + target.name() + ' aumentano!';
      break;

    //MILKSHAKE BUNNY//
    case 'MSB ATTACK': //MILKSHAKE BUNNY ATTACK
      text = user.name() + ' fa cadere del milkshake su ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'MSB NOTHING': //MILKSHAKE BUNNY NOTHING
      text = user.name() + ' corre in cerchio.';
      break;

    case 'MSB SHAKE': //MILKSHAKE BUNNY SHAKE
      text = user.name() + ' comincia ad agitarsi furiosamente!\r\n';
      text += 'Il milkshake vola dappertutto!';
      break;

    //PANCAKE BUNNY//
    case 'PAN ATTACK': //PANCAKE BUNNY ATTACK
      text = user.name() + ' sgranocchia ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'PAN NOTHING': //PANCAKE BUNNY NOTHING
      text = user.name() + ' fa un salto!\r\n';
      text += 'Che talento!';
      break;

    //STRAWBERRY SHORT SNAKE//
    case 'SSS ATTACK': //STRAWBERRY SHORT SNAKE ATTACK
      text = user.name() + ' affonda le sue zanne su ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'SSS NOTHING': //STRAWBERRY SHORT SNAKE NOTHING
      text = user.name() + ' sibila.';
      break;

    case 'SSS SLITHER': //STRAWBERRY SHORT SNAKE SLITHER
      text = user.name() + ' striscia allegramente!\r\n';
      if(!user._noEffectMessage) {text += user.name() + ' diventa FELICE!';}
      else {text += parseNoEffectEmotion(user.name(), "più FELICE")}
      break;

    //PORCUPIE//
    case 'PORCUPIE ATTACK': //PORCUPIE ATTACK
      text = user.name() + ' colpisce ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'PORCUPIE NOTHING': //PORCUPIE NOTHING
      text = user.name() + ' annusa i dintorni.';
      break;

    case 'PORCUPIE PIERCE': //PORCUPIE PIERCE
      text = user.name() + ' infilza ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    //BUN BUNNY//
    case 'BUN ATTACK': //BUN ATTACK
      text = user.name() + ' impanina ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BUN NOTHING': //BUN NOTHING
      text = user.name() + ' non fa nulla.';
      break;

    case 'BUN HIDE': //BUN HIDE
      text = user.name() + ' si nasconde nel suo panino.';
      break;

    //TOASTY//
    case 'TOASTY ATTACK': //TOASTY ATTACK
      text = user.name() + ' corre verso ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'TOASTY NOTHING': //TOASTY NOTHING
      text = user.name() + ' si mette le dita nel naso.';
      break;

    case 'TOASTY RILE': //TOASTY RILE
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' fa un discorso controverso!\r\n';
        text += 'Tutti diventano ARRABBIATI!';
      }
      target._noEffectMessage = undefined;
      break;

    //SOURDOUGH//
    case 'SOUR ATTACK': //SOURDOUGH ATTACK
      text = user.name() + ' calpesta un dito di ' + target.name() + '\'s!\r\n';
      text += hpDamageText;
      break;

case 'SOUR NOTHING': //SOURDOUGH NOTHING
      text = user.name() + ' tira un calcio al terreno.';
      break;

    case 'SOUR BAD WORD': //SOURDOUGH BAD WORD
      text = 'Oh no! ' + user.name() + ' dice una parolaccia!\r\n';
      text += hpDamageText;
      break;

    //SESAME//
    case 'SESAME ATTACK': //SESAME ATTACK
      text = user.name() + ' lancia dei semi a ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'SESAME NOTHING': //SESAME Nothing
      text = user.name() + ' si gratta la testa.';
      break;

    case 'SESAME ROLL': //SESAME BREAD ROLL
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' rotola su tutti!\r\n';
      }
      text += hpDamageText;
      break;

    //CREEPY PASTA//
    case 'CREEPY ATTACK': //CREEPY ATTACK
      text = user.name() + ' fa sentire ' + target.name() + '\r\n';
      text += 'a disagio.\r\n';
      text += hpDamageText;
      break;

    case 'CREEPY NOTHING': //CREEPY NOTHING
      text = user.name() + ' non fa nulla... minacciosamente!';
      break;

    case 'CREEPY SCARE': //CREEPY SCARE
      text = user.name() + ' mostra a tutti i loro peggiori\r\n';
      text += 'incubi!';
      break;

    //COPY PASTA//
    case 'COPY ATTACK': //COPY ATTACK
      text = user.name() + ' dà un colpetto a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'DUPLICATE': //DUPLICATE
      text = user.name() + ' si duplica! ';
      break;

    //HUSH PUPPY//
    case 'HUSH ATTACK': //HUSH ATTACK
      text = user.name() + ' si scontra con ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'HUSH NOTHING': //HUSH NOTHING
      text = user.name() + ' prova ad abbaiare...\r\n';
      text += 'Ma senza successo...';
      break;

    case 'MUFFLED SCREAMS': //MUFFLED SCREAMS
      text = user.name() + ' comincia ad urlare!\r\n';
      if(!target._noEffectMessage && target.name() !== "OMORI") {
        text += target.name() + ' si IMPAURISCE.';
      }
      else {text += parseNoEffectEmotion(target.name(), "AFRAID")}
      break;

    //GINGER DEAD MAN//
    case 'GINGER DEAD ATTACK': //GINGER DEAD MAN ATTACK
      text = user.name() + ' colpisce ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'GINGER DEAD NOTHING': //GINGER DEAD MAN DO NOTHING
      text = user.name() + '\'s lascia cadere la sua testa...\r\n';
      text += user.name() + ' la rimette a posto.';
      break;

    case 'GINGER DEAD THROW HEAD': //GINGER DEAD MAN THROW HEAD
      text = user.name() + ' lancia la sua testa a\r\n';
      text +=  target.name() + '!\r\n';
      text += hpDamageText;
      break;

    //LIVING BREAD//
    case 'LIVING BREAD ATTACK': //LIVING BREAD ATTACK
      text = user.name() + ' colpisce ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'LIVING BREAD NOTHING': //LIVING BREAD ATTACK
      text = user.name() + ' si muove lentamente verso\r\n';
      text += target.name() + '!';
      break;

    case 'LIVING BREAD BITE': //LIVING BREAD BITE
      text = user.name() + ' morde ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'LIVING BREAD BAD SMELL': //LIVING BREAD BAD SMELL
      text = user.name() + ' ha un cattivo odore!\r\n';
      text += "La DIFESA di " + target.name() + ' cala.\r\n';
      break;

    //Bug Bunny//
    case 'BUG BUN ATTACK': //Bug Bun Attack
     text = user.name() + ' colpisce ' + target.name() + '!\r\n';
     text += hpDamageText;
     break;

    case 'BUG BUN NOTHING': //Bug Bun Nothing
      text = user.name() + ' prova a stare in piedi sulla sua testa.';
      break;

    case 'SUDDEN JUMP': //SUDDEN JUMP
      text = user.name() + ' salta improvvisamente su ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SCUTTLE': //Bug Bun Scuttle
      text = user.name() + ' corre in giro allegramente.\r\n';
      text += 'Che carino!\r\n';
      if(!user._noEffectMessage) {text += user.name() + ' diventa FELICE!';}
      else {text += parseNoEffectEmotion(user.name(), "più FELICE")}
      break;

    //RARE BEAR//
    case 'BEAR ATTACK': //BEAR ATTACK
      text = user.name() + ' attacca con gli artigli ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BEAR HUG': //BEAR HUG
      text = user.name() + ' abbraccia ' + target.name() + '!\r\n';
      text += "La VELOCITÀ di " + target.name() + ' cala!';
      text += hpDamageText;
      break;

    case 'ROAR': //ROAR
      text = user.name() + ' ruggisce con forza!\r\n';
      if(!user._noEffectMessage) {text += user.name() + ' si ARRABBIA!';}
      else {text += parseNoEffectEmotion(user.name(), "più ARRABBIATO")}
      break;

    //POTTED PALM//
    case 'PALM ATTACK': //PALM ATTACK
      text = user.name() + ' sbatte contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'PALM NOTHING': //PALM NOTHING
      text = user.name() + ' si sta riposando nel suo vaso. ';
      break;

    case 'PALM TRIP': //PALM TRIP
      text = target.name() + ' saltella su ' + user.name() + '\'s.\r\n';
      text += hpDamageText + '.\r\n';
      text += "La DIFESA di " + target.name() + ' cala!';
      break;

    case 'PALM EXPLOSION': //PALM EXPLOSION
      text = user.name() + ' esplode!';
      break;

    //SPIDER CAT//
    case  'SPIDER ATTACK': //SPIDER ATTACK
      text = user.name() + ' morde ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SPIDER NOTHING': //SPIDER NOTHING
      text = user.name() + ' tossisce una palla di ragnatele.';
      break;

    case 'SPIN WEB': //SPIN WEB
       text = user.name() + ' lancia ragnatele a ' + target.name() + '!\r\n';
       text += "La VELOCITÀ di " + target.name() + ' cala!';
       break;

    //SPROUT MOLE?//
    case 'SPROUT ATTACK 2':  // SPROUT MOLE? ATTACK
      text = user.name() + ' schiaffeggia ' + target.name() + '?\r\n';
      text += hpDamageText;
      break;

    case 'SPROUT NOTHING 2':  // SPROUT MOLE? NOTHING
      text = user.name() + ' rotola qua e là?';
      break;

    case 'SPROUT RUN AROUND 2':  // SPROUT MOLE? RUN AROUND
      text = user.name() + ' corre in giro?';
      break;

    //HAROLD//
    case 'HAROLD ATTACK': //HAROLD ATTACK
      text = user.name() + ' colpisce con la spada ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'HAROLD NOTHING': // HAROLD NOTHING
      text = user.name() + ' si aggiusta il suo elmetto.';
      break;

    case 'HAROLD PROTECT': // HAROLD PROTECT
      text = user.name() + ' si protegge.';
      break;

    case 'HAROLD WINK': //HAROLD WINK
      text = user.name() + " fa l'occhiolino a " + target.name() + '.\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' diventa FELICE!';}
      else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
      break;

    //MARSHA//
    case 'MARSHA ATTACK': //MARSHA ATTACK
      text = user.name() + ' colpisce con la sua ascia ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MARSHA NOTHING': //MARSHA NOTHING
      text = user.name() + ' si accascia. ';
      break;

    case 'MARSHA SPIN': //MARSHA NOTHING
      text = user.name() + ' comincia a ruotare a velocità mach!\r\n';
      text += hpDamageText;
      break;

    case 'MARSHA CHOP': //MARSHA CHOP
      text = user.name() + ' attacca con la sua ascia ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    //THERESE//
    case 'THERESE ATTACK': //THERESE ATTACK
      text = user.name() + ' tira una freccia a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'THERESE NOTHING': //THERESE NOTHING
      text = user.name() + ' fa cadere una freccia.';
      break;

    case 'THERESE SNIPE': //THERESE SNIPE
      text = user.name() + ' colpisce il punto debole di ' + target.name() + '\'s!\r\n';
      text += hpDamageText;
      break;

    case 'THERESE INSULT': //THERESE INSULT
      text = user.name() + ' chiama ' + target.name() + ' una testa di cavolo!\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' si ARRABBIA!\r\n';}
      else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
      text += hpDamageText;
      break;

    case 'DOUBLE SHOT': //THERESE DOUBLE SHOT
      text = user.name() + ' tira due freccie in una volta!';
      break;

    //LUSCIOUS//
    case 'LUSCIOUS ATTACK': //LUSCIOUS ATTACK
      text = user.name() + ' prova a lanciare un incantesimo...\r\n';
      text += user.name() + ' ha fatto qualcosa di magico!\r\n';
      text += hpDamageText;
      break;

    case 'LUSCIOUS NOTHING': //LUSCIOUS NOTHING
      text = user.name() + ' prova a lanciare un incantesimo...\r\n';
      text += 'Ma fallisce...';
      break;

    case 'FIRE MAGIC': //FIRE MAGIC
      text = user.name() + ' prova a lanciare un incantesimo...\r\n';
      text += user.name() + ' incendia la squadra!\r\n';
      text += hpDamageText;
      break;

    case 'MISFIRE MAGIC': //MISFIRE MAGIC
      text = user.name() + ' prova a lanciare un incantesimo...\r\n';
      text += user.name() + ' incendia la stanza!!!\r\n';
      text += hpDamageText;
      break;

    //HORSE HEAD//
    case 'HORSE HEAD ATTACK': //HORSE HEAD ATTACK
      text = user.name() + ' morde il braccio di ' + target.name() + '\'s.\r\n';
      text += hpDamageText;
      break;

    case 'HORSE HEAD NOTHING': //HORSE HEAD NOTHING
      text = user.name() + ' rutta.';
      break;

    case 'HORSE HEAD LICK': //HORSE HEAD LICK
     text = user.name() + ' lecca i capelli di ' + target.name() + '\'s\r\n';
     text += hpDamageText + '\r\n';
     if(!target._noEffectMessage) {text += target.name() + ' si ARRABBIA!';}
     else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
     break;

    case 'HORSE HEAD WHINNY': //HORSE HEAD WHINNY
      text = user.name() + ' nitrisce allegramente!';
      break;

    //HORSE BUTT//
    case 'HORSE BUTT ATTACK': //HORSE BUTT ATTACK
      text = user.name() + ' calpesta ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'HORSE BUTT NOTHING': //HORSE BUTT NOTHING
      text = user.name() + ' scoreggia.';
      break;

    case 'HORSE BUTT KICK': //HORSE BUTT KICK
      text = user.name() + ' tira un calcio a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'HORSE BUTT PRANCE': //HORSE BUTT PRANCE
      text = user.name() + ' salta in giro.';
      break;

    //FISH BUNNY//
    case 'FISH BUNNY ATTACK': //FISH BUNNY ATTACK
      text = user.name() + ' nuota contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'FISH BUNNY NOTHING': //FISH BUNNY NOTHING
      text = user.name() + ' nuota in cerchio. ';
      break;

    case 'SCHOOLING': //SCHOOLING
      text = user.name() + ' chiama i suoi amici! ';
      break;

    //MAFIA ALLIGATOR//
    case 'MAFIA ATTACK': //MAFIA ATTACK
      text = user.name() + ' fa una mossa di karate a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MAFIA NOTHING': //MAFIA NOTHING
      text = user.name() + ' si scrocchia le nocche.';
      break;

    case 'MAFIA ROUGH UP': //MAFIA ROUGH UP
      text = user.name() + ' picchia ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MAFIA BACK UP': //MAFIA ALLIGATOR BACKUP
      text = user.name() + ' chiama aiuto!';
      break;

    //MUSSEL//
    case 'MUSSEL ATTACK': //MUSSEL ATTACK
      text = user.name() + ' tira un pugno\r\na ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MUSSEL FLEX': //MUSSEL FLEX
     text = user.name() + ' flette i suoi muscoli\r\ne si sente un campione!\r\n';
     text += "La PRECISIONE di " + user.name() + ' aumenta!';
     break;

    case 'MUSSEL HIDE': //MUSSEL HIDE
     text = user.name() + ' si nasconde nel suo guscio.';
     break;

    //REVERSE MERMAID//
    case 'REVERSE ATTACK': //REVERSE ATTACK
     text = target.name() + ' sbatte contro ' + user.name() + '!\r\n';
     text += hpDamageText;
     break;

    case 'REVERSE NOTHING': //REVERSE NOTHING
     text = user.name() + ' fa un backflip!\r\n';
     text += 'WOW!';
     break;

    case 'REVERSE RUN AROUND': //REVERSE RUN AROUND
      text = 'Tutti scappano da ' + user.name() + ',\r\n';
      text += 'ma lo incontrano lo stesso...\r\n';
      text += hpDamageText;
      break;

    //SHARK FIN//
    case 'SHARK FIN ATTACK': //SHARK FIN ATTACK
      text = user.name() + ' carica verso ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SHARK FIN NOTHING': //SHARK FIN NOTHING
      text = user.name() + ' nuota in un cerchio.';
      break;

    case 'SHARK FIN BITE': //SHARK FIN BITE
      text = user.name() + ' morde ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SHARK WORK UP': //SHARK FIN WORK UP
      text = user.name() + ' si prepara!\r\n';
      text += "La VELOCITÀ di " + user.name() + ' aumenta!\r\n';
      if(!user._noEffectMessage) {
        text += user.name() + ' si ARRABBIA!';
      }
      else {text += parseNoEffectEmotion(user.name(), "più ARRABBIATO")}
      break;

    //ANGLER FISH//
    case 'ANGLER ATTACK': //ANGLER FISH ATTACK
      text = user.name() + ' morde ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'ANGLER NOTHING': //ANGLER FISH NOTHING
      text = ' Lo stomaco di ' + user.name() + '\'s brontola.'; 
      break;

    case 'ANGLER LIGHT OFF': //ANGLER FISH LIGHT OFF
      text = user.name() + ' spegne le luci.\r\n';
      text += user.name() + ' scompare nel buio.';
      break;

    case 'ANGLER BRIGHT LIGHT': //ANGLER FISH BRIGHT LIGHT
      text = 'Tutti si vedono passare la loro vita\r\n';
      text += 'davanti ai propri occhi!';
      break;

    case 'ANGLER CRUNCH': //ANGLER FISH CRUNCH
      text = user.name() + ' traffigge ' + target.name() + ' con i suoi denti!\r\n';
      text += hpDamageText;
      break;

    //SLIME BUNNY//
    case 'SLIME BUN ATTACK': //SLIME BUNNY ATTACK
      text = user.name() + ' si strofina su ' + target.name() +'.\r\n';
      text += hpDamageText;
      break;

    case 'SLIME BUN NOTHING': //SLIME BUN NOTHING
      text = user.name() + ' sorride a tutti.\r\n';
      break;

    case 'SLIME BUN STICKY': //SLIME BUN STICKY
      text = user.name() + ' si sente solo e piange.\r\n';
      if(!target._noStateMessage) {text += "La VELOCITÀ di" + target.name() + ' cala!\r\n';}
      else {text += parseNoStateChange(target.name(), "LA VELOCITÀ", "più bassa!")}
      text += target.name() + " diventa TRISTE.";
      break;

    //WATERMELON MIMIC//
    case 'WATERMELON RUBBER BAND': //WATERMELON MIMIC RUBBER BAND
      text = user.name() + ' lancia un ELASTICO DI GOMMA!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON JACKS': //WATERMELON MIMIC JACKS
      text = user.name() + ' lancia PETARDI dappertutto!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON DYNAMITE': //WATERMELON MIMIC DYNAMITE
      text = user.name() + ' lancia della DINAMITE!\r\n';
      text += 'OH NO!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON WATERMELON SLICE': //WATERMELON MIMIC WATERMELON SLICE
      text = user.name() + ' lancia SUCCO DI ANGURIA!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON GRAPES': //WATERMELON MIMIC GRAPES
      text = user.name() + ' lancia GAZZOSA ALL\'UVA!\r\n';
      text += hpDamageText;
      break;

    case 'WATEMELON FRENCH FRIES': //WATERMELON MIMIC FRENCH FRIES
      text = user.name() + ' lancia PATATINE FRITTE!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON CONFETTI': //WATERMELON MIMIC CONFETTI
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' lancia CORIANDOLI!\r\n';
        text += "Tutti diventano FELICI!"
      }
      target._noEffectMessage = undefined;
      break;

    case 'WATERMELON RAIN CLOUD': //WATERMELON MIMIC RAIN CLOUD
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' evoca una NUVOLA DI PIOGGIA!\r\n';
        text += "Tutti diventano TRISTI."
      }
      target._noEffectMessage = undefined;
      break;

    case 'WATERMELON AIR HORN': //WATERMELON MIMIC AIR HORN
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' usa una TROMBA AD ARIA!\r\n';
        text += "Tutti diventano ARRABBIATI!"
      }
      target._noEffectMessage = undefined;
      break;

    //SQUIZZARD//
    case 'SQUIZZARD ATTACK': //SQUIZZARD ATTACK
      text = user.name() + ' usa una magia su ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SQUIZZARD NOTHING': //SQUIZZARD NOTHING
      text = user.name() + ' borbotta parole insensate.';
      break;

    case 'SQUID WARD': //SQUID WARD
      text = user.name() + ' crea una barriera-calamaro.\r\n';
      text += "La DIFESA di " + target.name() + ' aumenta!';
      break;

    case  'SQUID MAGIC': //SQUID MAGIC
      text = user.name() +  ' lancia delle magie-calamaro!\r\n';
      text += 'Tutti iniziano a sentirsi strani...';
      break;

    //WORM-BOT//
    case 'BOT ATTACK': //MECHA WORM ATTACK
      text = user.name() + ' sbatte contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BOT NOTHING': //MECHA WORM NOTHING
      text = user.name() + ' mastica rumorosamente!';
      break;

    case 'BOT LASER': //MECHA WORM CRUNCH
      text = user.name() + ' spara un raggio a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BOT FEED': //MECHA WORM FEED
      text = user.name() + ' mangia ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;


    //SNOT BUBBLE//
    case 'SNOT INFLATE': //SNOT INFLATE
      text = user.name() + '\'s si ingrossa!\r\n';
      text += "L'ATTACCO di " + target.name() + ' aumenta!';
      break;

    case 'SNOT POP': //SNOT POP
      text = user.name() + ' esplode!\r\n';
      text += 'Il moccio vola da tutte le parti!!\r\n';
      text += hpDamageText;
      break;

    //LAB RAT//
    case  'LAB ATTACK': //LAB RAT ATTACK
      text = user.name() + ' spara un piccolo rattoraggio!\r\n';
      text += hpDamageText;
      break;

    case  'LAB NOTHING': //LAB RAT NOTHING
      text = user.name() + " fa uscire un po' di vapore.";
      break;

    case  'LAB HAPPY GAS': //LAB RAT HAPPY GAS
      text = user.name() + ' rilascia un gas che rende FELICI!\r\n';
      text += 'Tutti diventano FELICI!';
      target._noEffectMessage = undefined;
      break;

    case  'LAB SCURRY': //LAB RAT SCURRY
      text = user.name() + ' corre in giro!\r\n';
      break;

    //MECHA MOLE//
    case 'MECHA MOLE ATTACK': //MECHA MOLE ATTACK
      text = user.name() + ' spara un raggio a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MECHA MOLE NOTHING': //MECHA MOLE NOTHING
      text = ' Gli occhi di ' + user.name() + '\'s si illuminano.';
      break;

    case 'MECHA MOLE EXPLODE': //MECHA MOLE EXPLODE
      text = user.name() + ' versa una singola lacrima.\r\n';
      text += user.name() + ' esplode gloriosamente!';
      break;

    case 'MECHA MOLE STRANGE LASER': //MECHA MOLE STRANGE LASER
      text = ' Gli occhi di ' + user.name() + '\'s emettono una strana\r\n';
      text += 'luce. ' + target.name() + ' ha avuto una strana sensazione.';
      break;

    case 'MECHA MOLE JET PACK': //MECHA MOLE JET PACK
      text = 'Un jetpack è apparso su ' + user.name() + '!\r\n';
      text += user.name() + ' vola in mezzo a tutti!';
      break;

    //CHIMERA CHICKEN//
    case 'CHICKEN RUN AWAY': //CHIMERA CHICKEN RUN AWAY
      text = user.name() + ' corre via.';
      break;

    case 'CHICKEN NOTHING': //CHICKEN DO NOTHING
      text = user.name() + ' chioccia. ';
      break;

    //SALLI//
    case 'SALLI ATTACK': //SALLI ATTACK
      text = user.name() + ' corre contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SALLI NOTHING': //SALLI NOTHING
      text = user.name() + ' fa un piccolo salto!';
      break;

    case 'SALLI SPEED UP': //SALLI SPEED UP
      text = user.name() + ' sfreccia per la stanza!\r\n';
      if(!target._noStateMessage) {
        text += "La VELOCITÀ di " + user.name() + ' aumenta!';
      }
      else {text += parseNoStateChange(user.name(), "LA VELOCITÀ", "più alta!")}
      break;

    case 'SALLI DODGE ANNOY': //SALLI STARE
      text = user.name() + ' si concentra intensamente! ';
      break;

    //CINDI//
    case 'CINDI ATTACK': //CINDI ATTACK
      text = user.name() + ' colpisce ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'CINDI NOTHING': //CINDI NOTHING
      text = user.name() + ' piroetta in cerchio.';
      break;

    case 'CINDI SLAM': //CINDI SLAM
      text = user.name() + ' sbatte il suo braccio contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'CINDI COUNTER ATTACK': //CINDI COUNTER ATTACK
      text = user.name() + ' si prepara!';
      break;

    //DOROTHI//
    case 'DOROTHI ATTACK': //DOROTHI ATTACK
      text = user.name() + ' calpesta ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'DOROTHI NOTHING': //DOROTHI NOTHING
      text = user.name() + ' piange nel buio.';
      break;

    case 'DOROTHI KICK': //DOROTHI KICK
      text = user.name() + ' tira un calcio a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'DOROTHI HAPPY': //DOROTHI HAPPY
      text = user.name() + ' salta quà e là!';
      break;

    //NANCI//
    case 'NANCI ATTACK': //NANCI ATTACK
      text = user.name() + ' traffigge ' + target.name() + ' con i suoi artigli!\r\n';
      text += hpDamageText;
      break;

    case 'NANCI NOTHING': //NANCI NOTHING
      text = user.name() + 'ondeggia avanti e indietro.';
      break;

    case 'NANCI ANGRY': //NANCI ANGRY
      text = user.name() + ' inizia a riscaldarsi!';
      break;

    //MERCI//
    case 'MERCI ATTACK': //MERCI ATTACK
      text = user.name() + ' tocca il petto di ' + target.name() + '\'s.\r\n';
      text += target.name() + ' sente i suoi organi lacerarsi!\r\n';
      text += hpDamageText;
      break;

    case 'MERCI NOTHING': //MERCI NOTHING
      text = user.name() + ' fa un sorriso inquietante.';
      break;

    case 'MERCI MELODY': //MERCI LAUGH
      text = user.name() + ' canta una canzone.\r\n';
      text += target.name() + ' sente una melodia familiare.\r\n';
      if(target.isStateAffected(6)) {text += target.name() + " diventa FELICE!\r\n"}
      else if(target.isStateAffected(7)) {text += target.name() + " è in preda all'ESTASI!!\r\n"}
      else if(target.isStateAffected(8)) {text += target.name() + " è in preda alla MANIA!!!\r\n"}
      break;

    case 'MERCI SCREAM': //MERCI SCREAM
      text = user.name() + ' fa uno strillo orribile!\r\n';
      text += hpDamageText;
      break;


    //LILI//
    case 'LILI ATTACK': //LILI ATTACK
      text = user.name() + " scruta nell'anima di " + target.name() + '\'s!\r\n';
      text += hpDamageText;
      break;

    case 'LILI NOTHING': //LILI NOTHING
      text = user.name() + " fa l'occhiolino.";
      break;

    case 'LILI MULTIPLY': //LILI MULTIPLY
      text = " Un  occhio di " + user.name() + '\'s cade!\r\n';
      text += " L'occhio si trasforma in un'altra " + user.name() + '!';
      break;

    case 'LILI CRY': //LILI CRY
      text = 'Le lacrime stanno per riempire gli occhi di ' + user.name() + '\'s.\r\n';
      text += target.name() + " diventa TRISTE."
      break;

    case 'LILI SAD EYES': //LILI SAD EYES
      text = target.name() + ' vede la tristezza negli occhi di ' + user.name() + '\'s.\r\n';
      text += target.name() + ' è riluttante ad attaccare ' + user.name(); + '.\r\n'
      break;

    //HOUSEFLY//
    case 'HOUSEFLY ATTACK': //HOUSEFLY ATTACK
      text = user.name() + ' si mette sulla faccia di ' + target.name() + '\'s.\r\n';
      text += target.name() + ' si tira uno schiaffo in faccia!\r\n';
      text += hpDamageText;
      break;

    case 'HOUSEFLY NOTHING': //HOUSEFLY NOTHING
      text = user.name() + ' vola rapidamente in giro!';
      break;

    case 'HOUSEFLY ANNOY': //HOUSEFLY ANNOY
      text = user.name() + " vola intorno all'orecchio di " + target.name() + '\'s!\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' si ARRABBIA!';}
      else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
      break;

    //RECYCLIST//
    case 'FLING TRASH': //FLING TRASH
      text = user.name() + ' tira SPAZZATURA a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'GATHER TRASH': //GATHER TRASH
      text = user.name() + ' trova della SPAZZATURA per terra\r\n';
      text += 'e la mette nel suo sacchetto!\r\n';
      text += hpDamageText;
      break;

    case 'RECYCLIST CALL FOR FRIENDS': //RECYCLIST CALL FOR FRIENDS
      text = user.name() + ' fa il richiamo dei RICICULTISTI\'s!!';
      break;

    //STRAY DOG//
    case 'STRAY DOG ATTACK': //STRAY DOG ATTACK
      text = user.name() + ' usa un attacco mordente!\r\n';
      text += hpDamageText;
      break;

    case 'STRAY DOG HOWL': //STRAY DOG HOWL
      text = user.name() + ' fa un perforante ululo!';
      break;

    //CROW//
    case 'CROW ATTACK': //CROW ATTACK
      text = user.name() + ' becca gli occhi di ' + target.name() + '\'s.\r\n';
      text += hpDamageText;
      break;

    case 'CROW GRIN': //CROW GRIN
      text = user.name() + ' ha un gran sorriso in faccia.';
      break;

    case 'CROW STEAL': //CROW STEAL
      text = user.name() + ' ruba qualcosa!';
      break;

    // BEE //
    case 'BEE ATTACK': //BEE Attack
      text = user.name() + ' punge ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'BEE NOTHING': //BEE NOTHING
      text = user.name() + ' vola velocemente quà e là!';
      break;

    // GHOST BUNNY //
    case 'GHOST BUNNY ATTACK': //GHOST BUNNY ATTACK
      text = user.name() + ' passa attraverso a ' + target.name() + '!\r\n';
      text += target.name() + ' si stanca.\r\n';
      text += mpDamageText;
      break;

    case 'GHOST BUNNY NOTHING': //GHOST BUNNY DO NOTHING
      text = user.name() + ' fluttua sul posto.';
      break;

    //TOAST GHOST//
    case 'TOAST GHOST ATTACK': //TOAST GHOST ATTACK
      text = user.name() + ' passa attraverso a ' + target.name() + '!\r\n';
      text += target.name() + ' si stanca.\r\n';
      text += hpDamageText;
      break;

    case 'TOAST GHOST NOTHING': //TOAST GHOST NOTHING
      text = user.name() + ' fa un rumore inquietante.';
      break;

    //SPROUT BUNNY//
    case 'SPROUT BUNNY ATTACK': //SPROUT BUNNY ATTACK
      text = user.name() + ' schiaffeggia ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'SPROUT BUNNY NOTHING': //SPROUT BUNNY NOTHING
      text = user.name() + ' mordicchia un po\' d\'erba.';
      break;

    case 'SPROUT BUNNY FEED': //SPROUT BUNNY FEED
      text = user.name() + ' dà da mangiare a ' + target.name() + '.\r\n';
      text += `${user.name()} recupera ${Math.abs(hpDam)} di VITA!`
      break;

    //CELERY//
    case 'CELERY ATTACK': //CELERY ATTACK
      text = user.name() + ' si scontra con ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'CELERY NOTHING': //CELERY NOTHING
      text = user.name() + ' cade.';
      break;

    //CILANTRO//
    case 'CILANTRO ATTACK': //CILANTRO ATTACK
      text = user.name() + ' colpisce ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'CILANTRO NOTHING': //CILANTRO DO NOTHING
      text = user.name() + ' riflette sulla sua vita.';
      break;

    case 'GARNISH': //CILANTRO GARNISH
      text = user.name() + ' si sacrifica\r\n';
      text += 'per migliorare ' + target.name() + '.';
      break;

    //GINGER//
    case 'GINGER ATTACK': //GINGER ATTACK
      text = user.name() + ' scatta e attacca ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'GINGER NOTHING': //GINGER NOTHING
      text = user.name() + ' trova la pace interiore.';
      break;

    case 'GINGER SOOTHE': //GINGER SOOTHE
      text = user.name() + ' calma ' + target.name() + '.\r\n';
      break;

    //YE OLD MOLE//
    case 'YE OLD ROLL OVER': //MEGA SPROUT MOLE ROLL OVER
      text = user.name() + ' investe tutti rotolando!';
      text += hpDamageText;
      break;

    //KITE KID//
    case 'KITE KID ATTACK':  // KITE KID ATTACK
      text = user.name() + ' lancia PETARDI a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'KITE KID BRAG':  // KITE KID BRAG
      text = user.name() + ' si vanta del suo AQUILONE!\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + ' diventa FELICE!';
      }
      else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
      break;

    case 'REPAIR':  // REPAIR
      text = user.name() + ' aggiusta il suo AQUILONE!\r\n';
      text += 'L\'AQUILONE DEL BAMBINO si sente come nuovo!';
      break;

    //KID'S KITE//
    case 'KIDS KITE ATTACK': // KIDS KITE ATTACK
      text = user.name() + ' plana contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'KITE NOTHING': // KITE NOTHING
      text = user.name() + ' gonfia il petto con orgoglio!';
      break;

    case 'FLY 1':  // FLY 1
      text = user.name() + ' vola molto alto!';
      break;

    case 'FLY 2':  // FLY 2
      text = user.name() + ' plana giù!!';
      break;

    //PLUTO//
    case 'PLUTO NOTHING':  // PLUTO NOTHING
      text = user.name() + ' si mette in posa!\r\n';
      break;

    case 'PLUTO HEADBUTT':  // PLUTO HEADBUTT
      text = user.name() + ' scatta in avanti e colpisce ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'PLUTO BRAG':  // PLUTO BRAG
      text = user.name() + ' si vanta dei suoi muscoli!\r\n';
      if(!user._noEffectMessage) {
        text += user.name() + ' diventa FELICE!';
      }
      else {text += parseNoEffectEmotion(user.name(), "più FELICE")}
      break;

    case 'PLUTO EXPAND':  // PLUTO EXPAND
      text = user.name() + ' si espande!!\r\n';
      if(!target._noStateMessage) {
        text += "La DIFESA e l'ATTACCO di " + user.name() + ' aumentano!!\r\n';
        text += "La VELOCITÀ di" + user.name() + ' cala.';
      }
      else {
        text += parseNoStateChange(user.name(), "L'ATTACCO", "più alto!")
        text += parseNoStateChange(user.name(), "LA DIFESA", "più alta!")
        text += parseNoStateChange(user.name(), "LA VELOCITÀ", "più bassa!")
      }
      break;

    case 'EXPAND NOTHING':  // PLUTO NOTHING
      text = "I muscoli di" + user.name();
      text += 'ti intimoriscono.';
      break;

    //RIGHT ARM//
    case 'R ARM ATTACK':  // R ARM ATTACK
      text = user.name() + ' colpisce ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'GRAB':  // GRAB
      text = user.name() + ' prende ' + target.name() + '!\r\n';
      text += "La VELOCITÀ di " + target.name() + ' cala.\r\n';
      text += hpDamageText;
      break;

    //LEFT ARM//
    case 'L ARM ATTACK':  // L ARM ATTACK
      text = user.name() + ' tira un pugno\r\na ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'POKE':  // POKE
      text = user.name() + ' punzecchia ' + target.name() + '!\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + ' si ARRABBIA!\r\n';
      }
      else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
      text += hpDamageText;
      break;

    //DOWNLOAD WINDOW//
    case 'DL DO NOTHING':  // DL DO NOTHING
      text = user.name() + ' è al 99%.';
      break;

    case 'DL DO NOTHING 2':  // DL DO NOTHING 2
      text = user.name() + ' è ancora al 99%...';
      break;

    case 'DOWNLOAD ATTACK':  // DOWNLOAD ATTACK
      text = user.name() + ' si blocca ed esplode!';
      break;

    //SPACE EX-BOYFRIEND//
    case 'SXBF ATTACK':  // SXBF ATTACK
      text = user.name() + ' dà un calcio a ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SXBF NOTHING':  // SXBF NOTHING
      text = user.name() + ' guarda con malinconia\r\n';
      text += 'il vuoto.';
      break;

    case 'ANGRY SONG':  // ANGRY SONG
      text = user.name() + ' si lamenta intensamente!';
      break;

    case 'ANGSTY SONG':  // ANGSTY SONG
      text = user.name() + ' canta tristemente...\r\n';
      if(target.isStateAffected(10)) {text += target.name() + ' diventa TRISTE.';}
      else if(target.isStateAffected(11)) {text += target.name() + ' è in preda alla DEPRESSIONE..';}
      else if(target.isStateAffected(12)) {text += target.name() + ' è colpito dalla MISERIA...';}
      break;

    case 'BIG LASER':  // BIG LASER
      text = user.name() + ' spara il suo laser!\r\n';
      text += hpDamageText;
      break;

    case 'BULLET HELL':  // BULLET HELL
      text = user.name() + ' spara il suo\r\n';
      text += 'laser selvaggiamente per la disperazione!';
      break;

    case 'SXBF DESPERATE':  // SXBF NOTHING
      text = user.name() + '\r\n';
      text += 'digrigna i denti!';
      break;

    //THE EARTH//
    case 'EARTH ATTACK':  // EARTH ATTACK
      text = user.name() + ' attacca ' + target.name() + '!\r\n';
      text += hpDamageText
      break;

    case 'EARTH NOTHING':  // EARTH NOTHING
      text = user.name() + ' ruota lentamente.';
      break;

    case 'EARTH CRUEL':  // EARTH CRUEL
      text = user.name() + ' è crudele nei confronti di ' + target.name() + "!\r\n";
      if(target.isStateAffected(10)) {text += target.name() + ' diventa TRISTE.';}
      else if(target.isStateAffected(11)) {text += target.name() + ' è in preda alla DEPRESSIONE..';}
      else if(target.isStateAffected(12)) {text += target.name() + ' è in preda alla MISERIA...';}
      break;

    case 'CRUEL EPILOGUE':  // EARTH CRUEL
      if(target.index() <= unitLowestIndex) {
        text = user.name() + " è crudele verso tutti...\r\n";
        text += "Tutti diventano TRISTI."
      }
      break;

    case 'PROTECT THE EARTH':  // PROTECT THE EARTH
      text = user.name() + ' usa il suo attacco più forte!';
      break;

    //SPACE BOYFRIEND//
    case 'SBF ATTACK': //SPACE BOYFRIEND ATTACK
      text = user.name() + ' calcia rapidamente ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SBF LASER': //SPACE BOYFRIEND LASER
      text = user.name() + ' spara il suo laser!\r\n';
      text += hpDamageText;
      break;

    case 'SBF CALM DOWN': //SPACE BOYFRIEND CALM DOWN
      text = user.name() + ' svuota la sua mente\r\n';
      text += 'e rimuove tutte le sue EMOZIONI.';
      break;

    case 'SBF ANGRY SONG': //SPACE BOYFRIEND ANGRY SONG
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' piange con tutta la sua rabbia!\r\n';
        text += "Tutti si ARRABBIANO!\r\n";
      }
      text += hpDamageText;
      break;

    case 'SBF ANGSTY SONG': //SPACE BOYFRIEND ANGSTY SONG
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' canta con tutta l\'oscurità\r\n';
        text += 'nella sua anima!\r\n';
        text += "Tutti diventano TRISTI.\r\n";
      }
      text += mpDamageText;
      break;

    case 'SBF JOYFUL SONG': //SPACE BOYFRIEND JOYFUL SONG
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' canta con tutta la gioia\r\n';
        text += "nel suo cuore!\r\n"
        text += "Tutti diventano FELICI!\r\n";
      }
      text += hpDamageText;
      break;

    //NEFARIOUS CHIP//
    case 'EVIL CHIP ATTACK': //NEFARIOUS CHIP ATTACK
      text = user.name() + ' va alla carica contro ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'EVIL CHIP NOTHING': //NEFARIOUS CHIP NOTHING
      text = user.name() + ' accarezza i suoi perfidi\r\n';
      text += 'baffi!';
      break;


    case 'EVIL LAUGH': //NEFARIOUS LAUGH
      text = user.name() + ' ride come il vero super\r\n';
      text += 'cattivo che è!\r\n';
      if(!target._noEffectMessage) {text += target.name() + " diventa FELICE!"}
      else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
      break;

    case 'EVIL COOKIES': //NEFARIOUS COOKIES
      text = user.name() + " lancia BISCOTTI DI FARINA D'AVENA a tutti!\r\n";
      text += 'Che cattiveria!';
      break;

    //BISCUIT AND DOUGHIE//
    case 'BD ATTACK': //BISCUIT AND DOUGHIE ATTACK
      text = user.name() + ' attaccano insieme!\r\n';
      text += hpDamageText;
      break;

    case 'BD NOTHING': //BISCUIT AND DOUGHIE NOTHING
      text = user.name() + ' dimenticano qualcosa\r\n';
      text += 'nel forno!';
      break;

    case 'BD BAKE BREAD': //BISCUIT AND DOUGHIE BAKE BREAD
      text = user.name() + ' tirano fuori\r\n';
      text += 'il PANE dal forno!';
      break;

    case 'BD COOK': //BISCUIT AND DOUGHIE CHEER UP
      text = user.name() + ' fanno un biscotto!\r\n';
      text += `${target.name()} recuperano ${Math.abs(hpDam)}\r\ndi VITA!`
      break;

    case 'BD CHEER UP': //BISCUIT AND DOUGHIE CHEER UP
      text = user.name() + ' fanno del loro meglio per non\r\n';
      text += 'essere TRISTI.';
      break;

    //KING CRAWLER//
    case 'KC ATTACK': //KING CRAWLER ATTACK
      text = user.name() + ' colpisce ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'KC NOTHING': //KING CRAWLER NOTHING
      text = user.name() + ' fà un urlo\r\n';
      text += 'spacca-timpani!\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + " si ARRABBIA!";
      }
      else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
      break;

    case 'KC CONSUME': //KING CRAWLER CONSUME
      text = user.name() + ' mangia una\r\n';
      text += "BULBOTALPA SMARRITA!\r\n"
      text += `${target.name()} recupera ${Math.abs(hpDam)} di VITA!\r\n`;
      break;

    case 'KC RECOVER': //KING CRAWLER CONSUME
      text = `${target.name()} recupera ${Math.abs(hpDam)} di VITA!\r\n`;
      if(!target._noEffectMessage) {text += target.name() + " diventa FELICE!"}
      else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
      break;

    case 'KC CRUNCH': //KING CRAWLER CRUNCH
      text = user.name() + ' morde ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'KC RAM': //KING CRAWLER RAM
      text = user.name() + ' colpisce tutta la squadra!\r\n';
      text += hpDamageText;
      break;

    //KING CARNIVORE//

    case "SWEET GAS":
      if(target.index() <= unitLowestIndex) {
        text = user.name() + " rilascia del gas!\r\n";
        text += "Profuma di dolce!\r\n";
        text += "Tutti diventano FELICI!";
      }
      target._noEffectMessage = undefined;
      break;

    //SPROUTMOLE LADDER//
    case 'SML NOTHING': //SPROUT MOLE LADDER NOTHING
      text = user.name() + ' sta fermo sul posto.';
      break;

    case 'SML SUMMON MOLE': //SPROUT MOLE LADDER SUMMON SPROUT MOLE
      text = 'Una BULBOTALPA cammina su ' + user.name() + '!';
      break;

    case 'SML REPAIR': //SPROUT MOLE LADDER REPAIR
      text = user.name() + ' è stato curato.';
      break;

    //UGLY PLANT CREATURE//
    case 'UPC ATTACK': //UGLY PLANT CREATURE ATTACK
      text = user.name() + ' avvolge\r\n';
      text += target.name() + ' con le liane!\r\n';
      text += hpDamageText;
      break;

    case 'UPC NOTHING': //UGLY PLANT CRATURE NOTHING
      text = user.name() + ' ruggisce!';
      break;

    //ROOTS//
    case 'ROOTS NOTHING': //ROOTS NOTHING
      text = user.name() + ' si dimena.';
      break;

    case 'ROOTS HEAL': //ROOTS HEAL
      text = user.name() + ' procura nutrimento per\r\n';
      text += target.name() + '.';
      break;

    //BANDITO MOLE//
    case 'BANDITO ATTACK': //BANDITO ATTACK
      text = user.name() + ' taglia ' + target.name() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BANDITO STEAL': //BANDITO STEAL
      text = user.name() + ' ruba di soppiatto un oggetto\r\n';
      text += 'alla squadra!'
      break;

    case 'B.E.D.': //B.E.D.
      text = user.name() + ' tira fuori il L.E.T.T.O.!\r\n';
      text += hpDamageText;
      break;

    //SIR MAXIMUS//
    case 'MAX ATTACK': //SIR MAXIMUS ATTACK
      text = user.name() + ' usa la sua spada!\r\n';
      text += hpDamageText;
      break;

    case 'MAX NOTHING': //SIR MAXIMUS NOTHING
      text = user.name() + ' si tira indietro...\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + ' diventa TRISTE.'
      }
      else {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
      break;

    case 'MAX STRIKE': //SIR MAXIMUS SWIFT STRIKE
      text = user.name() + ' colpisce due volte!';
      break;

    case 'MAX ULTIMATE ATTACK': //SIR MAXIMUS ULTIMATE ATTACK
      text = '"PREPARATEVI PER IL MIO ATTACCO FINALE!"';
      text += hpDamageText;
      break;

    case 'MAX SPIN': //SIR MAXIMUS SPIN
        break;

    //SIR MAXIMUS II//
    case 'MAX 2 NOTHING': //SIR MAXIMUS II NOTHING
      text = user.name() + ' ricorda le ultime\r\n';
      text += 'parole di suo padre.\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + ' diventa TRISTE.'
      }
      else {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
      break;

    //SIR MAXIMUS III//
    case 'MAX 3 NOTHING': //SIR MAXIMUS III NOTHING
      text = user.name() + ' ricorda le ultime\r\n';
      text += 'parole di suo nonno.\r\n'
      text += target.name() + ' diventa TRISTE.'
      break;

    //SWEETHEART//
    case 'SH ATTACK': //SWEET HEART ATTACK
      text = user.name() + ' schiaffeggia ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'SH INSULT': //SWEET HEART INSULT
      if(target.index() <= unitLowestIndex) {
        text = user.name() + " insulta tutti!\r\n"
        text += "Tutti si ARRABBIANO!\r\n";
      }
      text += hpDamageText;
      target._noEffectMessage = undefined;
      break;

    case 'SH SNACK': //SWEET HEART SNACK
      text = user.name() + ' ordina ad un servo di portarle\r\n';
      text += 'uno SNACK.\r\n';
      text += hpDamageText;
      break;

    case 'SH SWING MACE': //SWEET HEART SWING MACE
      text = user.name() + ' ruota la sua mazza con fervore!\r\n';
      text += hpDamageText;
      break;

    case 'SH BRAG': //SWEET HEART BRAG
      text = user.name() + ' si vanta\r\n';
      text += 'di uno dei suoi molti, molti talenti!\r\n';
      if(!target._noEffectMessage) {
        if(target.isStateAffected(8)) {text += target.name() + ' è in preda alla MANIA!!!';}
      else if(target.isStateAffected(7)) {text += target.name() + ' è in preda all\'ESTASI!!';}
      else if(target.isStateAffected(6)) {text += target.name() + ' diventa FELICE!';}
      }
      else {text += parseNoEffectEmotion(target.name(), "più FELICE")}

      break;

      //MR. JAWSUM //
      case 'DESK SUMMON MINION': //MR. JAWSUM DESK SUMMON MINION
        text = user.name() + ' prende il telefono e\r\n';
        text += 'chiama un ALLISGHERRO!';
        break;

      case 'JAWSUM ATTACK ORDER': //MR. JAWSUM DESK ATTACK ORDER
        if(target.index() <= unitLowestIndex) {
          text = user.name() + " dà l'ordine di attacco!\r\n";
          text += "Tutti si ARRABBIANO!";
        }
        break;

      case 'DESK NOTHING': //MR. JAWSUM DESK DO NOTHING
        text = user.name() + ' inizia a contare le VONGOLE.';
        break;

      //PLUTO EXPANDED//
      case 'EXPANDED ATTACK': //PLUTO EXPANDED ATTACK
        text = user.name() + ' lancia la Luna a\r\n';
        text += target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'EXPANDED SUBMISSION HOLD': //PLUTO EXPANDED SUBMISSION HOLD
        text = user.name() + ' intrappola ' + target.name() + '\r\n';
        text += 'in una presa di sottomissione!\r\n';
        text += "La VELOCITÀ di " + target.name() + ' cala.';
        text += hpDamageText;
        break;

      case 'EXPANDED HEADBUTT': //PLUTO EXPANDED HEADBUTT
        text = user.name() + ' da una testata\r\n';
        text += 'a ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'EXPANDED FLEX COUNTER': //PLUTO EXPANDED FLEX COUNTER
        text = user.name() + ' flette i suoi muscoli e\r\n'
        text += 'si prepara!';
        break;

      case 'EXPANDED EXPAND FURTHER': //PLUTO EXPANDED EXPAND FURTHER
        text = user.name() + ' si espande ancora di più!\r\n';
        if(!target._noStateMessage) {
          text += "L'ATTACCO di " + target.name() + ' aumenta!\r\n';
          text += "La DIFESA di " + target.name() + ' aumenta!\r\n';
          text += "La VELOCITÀ di " + target.name() + ' cala.';
        }
        else {
          text += parseNoStateChange(user.name(), "L'ATTACCO", "più alto!")
          text += parseNoStateChange(user.name(), "LA DIFESA", "più alta!")
          text += parseNoStateChange(user.name(), "LA VELOCITÀ", "più bassa!")
        }
        break;

      case 'EXPANDED EARTH SLAM': //PLUTO EXPANDED EARTH SLAM
        text = user.name() + ' prende la Terra\r\n';
        text += 'e la lancia su tutti!';
        break;

      case 'EXPANDED ADMIRATION': //PLUTO EXPANDED ADMIRATION
        text = user.name() + ' ammira i progressi di KEL!\r\n';
        if(target.isStateAffected(8)) {text += target.name() + ' è in preda alla MANIA!!!';}
        else if(target.isStateAffected(7)) {text += target.name() + ' è in preda all\'ESTASI!!';}
        else if(target.isStateAffected(6)) {text += target.name() + ' diventa FELICE!';}
        break;

      //ABBI TENTACLE//
      case 'TENTACLE ATTACK': //ABBI TENTACLE ATTACK
        text = user.name() + ' colpisce ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'TENTACLE TICKLE': //ABBI TENTACLE TICKLE
        text = user.name() + " indebolisce " + target.name() + "!\r\n";
        // var pronumn = target.name() === "AUBREY" ? "sua" : "suo";
        text += `${target.name()} abbassa la guardia!`
        break;

      case 'TENTACLE GRAB': //ABBI TENTACLE GRAB
        text = user.name() + ' si avvolge attorno a ' + target.name() + '!\r\n';
        if(result.isHit()) {
          if(target.name() !== "OMORI" && !target._noEffectMessage) {text += target.name() + " si IMPAURISCE\r\n";}
          else {text += parseNoEffectEmotion(target.name(), "AFRAID")}
        }
        text += hpDamageText;
        break;

      case 'TENTACLE GOOP': //ABBI TENTACLE GOOP
        text = ' Ricopre ' + target.name() + ' di un liquido scuro!\r\n';
        text += target.name() + ' si sente più debole...\r\n';
        text += "L'ATTACCO di " + target.name() + ' cala.';
        text += "La DIFESA di " + target.name() + ' cala.';
        text += "La VELOCITÀ di " + target.name() + ' cala.';
        break;

      //ABBI//
      case 'ABBI ATTACK': //ABBI ATTACK
        text = user.name() + ' attacca ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'ABBI REVIVE TENTACLE': //ABBI REVIVE TENTACLE
        text = user.name() + ' si concentra sulla sua VITA.';
        break;

      case 'ABBI VANISH': //ABBI VANISH
        text = user.name() + ' scompare nelle tenebre...';
        break;

      case 'ABBI ATTACK ORDER': //ABBI ATTACK ORDER
        if(target.index() <= unitLowestIndex) {
          text = user.name() + ' allunga i suoi tentacoli.\r\n';
          text += "L'ATTACCO di tutti aumenta!!\r\n"
          text += "Tutti si ARRABBIANO!"
        }
        break;

      case 'ABBI COUNTER TENTACLE': //ABBI COUNTER TENTACLES
        text = user.name() + " si muove nell'oscurità...";
        break;

      //ROBO HEART//
      case 'ROBO HEART ATTACK': //ROBO HEART ATTACK
        text = user.name() + ' spara le sue mani-razzo!\r\n';
        text += hpDamageText;
        break;

      case 'ROBO HEART NOTHING': //ROBO HEART NOTHING
        text = user.name() + ' è in buffering...';
        break;

      case 'ROBO HEART LASER': //ROBO HEART LASER
        text = user.name() + ' apre la sua bocca e\r\n';
        text += 'spara un raggio laser!\r\n';
        text += hpDamageText;
        break;

      case 'ROBO HEART EXPLOSION': //ROBO HEART EXPLOSION
        text = user.name() + ' versa una singola robot-lacrima.\r\n';
        text += user.name() + ' esplode!';
        break;

      case 'ROBO HEART SNACK': //ROBO HEART SNACK
        text = user.name() + ' apre la sua bocca.\r\n';
        text += 'Uno SNACK nutriente appare!\r\n';
        text += hpDamageText;
        break;

      //MUTANT HEART//
      case 'MUTANT HEART ATTACK': //MUTANT HEART ATTACK
        text = user.name() + ' canta una canzone per ' + target.name() + '!\r\n';
        text += 'Poteva fare di meglio...\r\n';
        text += hpDamageText;
        break;

      case 'MUTANT HEART NOTHING': //MUTANT HEART NOTHING
        text = user.name() + ' si mette in posa!';
        break;

      case 'MUTANT HEART HEAL': //MUTANT HEART HEAL
        text = user.name() + ' si sistema il vestito!';
        text += hpDamageText;
        break;

      case 'MUTANT HEART WINK': //MUTANT HEART WINK
        text = user.name() + " fa l'occhiolino a " + target.name() + '!\r\n';
        text += 'Che carina...\r\n';
        if(!target._noEffectMessage){text += target.name() + ' diventa FELICE!';}
        else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
        break;

      case 'MUTANT HEART INSULT': //MUTANT HEART INSULT
        text = user.name() + ' dice qualcosa di cattivo\r\n';
        text += 'per sbaglio.\r\n';
        if(!target._noEffectMessage){text += target.name() + ' si ARRABBIA!';}
        else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
        break;

      case 'MUTANT HEART KILL': //MUTANT HEART KILL
        text = 'MUTANTHEART schiaffeggia ' + user.name() +'!\r\n';
        text += hpDamageText;
        break;

        //PERFECT HEART//
        case 'PERFECT STEAL HEART': //PERFECT HEART STEAL HEART
          text = user.name() + ' ruba della VITA a ' + target.name() + '\r\n';
          text += '.\r\n';
          text += hpDamageText + "\r\n";
          if(user.result().hpDamage < 0) {text += `${user.name()} recupera ${Math.abs(user.result().hpDamage)} di VITA!\r\n`}
          break;

        case 'PERFECT STEAL BREATH': //PERFECT HEART STEAL BREATH
          text = user.name() + ' ruba il fiato a ' + target.name() + '\r\n';
          text += '.\r\n';
          text += mpDamageText + "\r\n";
          if(user.result().mpDamage < 0) {text += `${user.name()} recupera ${Math.abs(user.result().mpDamage)} di SUCCO...\r\n`}
          break;

        case 'PERFECT EXPLOIT EMOTION': //PERFECT HEART EXPLOIT EMOTION
          text = user.name() + ' si approfitta delle emozioni di ' + target.name() + '\'s\r\n';
          text += '!\r\n';
          text += hpDamageText;
          break;

        case 'PERFECT SPARE': //PERFECT SPARE
          text = user.name() + ' decide di lasciare\r\n';
          text += target.name() + ' in vita.\r\n';
          text += hpDamageText;
          break;

        case 'PERFECT ANGELIC VOICE': //UPLIFTING HYMN
          if(target.index() <= unitLowestIndex) {
            text = user.name() + ' canta una canzone piena di sentimento...\r\n';
            if(!user._noEffectMessage) {text += user.name() + " diventa TRISTE.\r\n"}
            else {text += parseNoEffectEmotion(user.name(), "più TRISTE")}
            text += 'Tutti diventano FELICI!';
          }
          break;

        case "PERFECT ANGELIC WRATH":
          if(target.index() <= unitLowestIndex) {text = user.name() + " scatena la sua furia.\r\n";}
          if(!target._noEffectMessage) {
              if(target.isStateAffected(8)) {text += target.name() + ' è in preda alla MANIA!!!\r\n';}
              else if(target.isStateAffected(7)) {text += target.name() + ' è in preda all\'ESTASI!!';}
              else if(target.isStateAffected(6)) {text += target.name() + ' diventa FELICE!\r\n';}
              else if(target.isStateAffected(12)) {text += target.name() + ' è in preda alla MISERIA...';}
              else if(target.isStateAffected(11)) {text += target.name() + ' è in preda alla DEPRESSIONE..';}
              else if(target.isStateAffected(10)) {text += target.name() + ' diventa TRISTE.\r\n';}
              else if(target.isStateAffected(12)) {text += target.name() + ' è in preda alla FURIA!!';}
              else if(target.isStateAffected(11)) {text += target.name() + ' è in preda all\'IRA!!!';}
              else if(target.isStateAffected(10)) {text += target.name() + ' si ARRABBIA!\r\n';}
          }
          else {
            if(target.isEmotionAffected("happy")) {text += parseNoEffectEmotion(target.name(), "più FELICE")}
            else if(target.isEmotionAffected("sad")) {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
            else if(target.isEmotionAffected("angry")) {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
          }
          text += hpDamageText;
          break;

        //SLIME GIRLS//
        case 'SLIME GIRLS COMBO ATTACK': //SLIME GIRLS COMBO ATTACK
          text = 'Le ' + user.name() + ' attacca\r\ntutti in una volta!\r\n';
          text += hpDamageText;
          break;

        case 'SLIME GIRLS DO NOTHING': //SLIME GIRLS DO NOTHING
          text = 'MEDUSA lancia una pozione...\r\n';
          text += 'Ma non succede niente...';
          break;

        case 'SLIME GIRLS STRANGE GAS': //SLIME GIRLS STRANGE GAS
            if(!target._noEffectMessage) {
              if(target.isStateAffected(8)) {text += target.name() + ' è in preda alla MANIA!!!\r\n';}
              else if(target.isStateAffected(7)) {text += target.name() + ' è in preda all\'ESTASI!!';}
              else if(target.isStateAffected(6)) {text += target.name() + ' diventa FELICE!\r\n';}
              else if(target.isStateAffected(12)) {text += target.name() + ' è in preda alla MISERIA...';}
              else if(target.isStateAffected(11)) {text += target.name() + ' è in preda alla DEPRESSIONE..';}
              else if(target.isStateAffected(10)) {text += target.name() + ' diventa TRISTE.\r\n';}
              else if(target.isStateAffected(16)) {text += target.name() + ' è in preda alla FURIA!!';}
              else if(target.isStateAffected(15)) {text += target.name() + ' è in preda all\'IRA!!!';}
              else if(target.isStateAffected(14)) {text += target.name() + ' si ARRABBIA!\r\n';}
          }
          else {
            if(target.isEmotionAffected("happy")) {text += parseNoEffectEmotion(target.name(), "più FELICE")}
            else if(target.isEmotionAffected("sad")) {text += parseNoEffectEmotion(target.name(), "più TRISTE")}
            else if(target.isEmotionAffected("angry")) {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
          }
          break;

        case 'SLIME GIRLS DYNAMITE': //SLIME GIRLS DYNAMITE
          //text = 'MEDUSA lancia una pozione...\r\n';
          //text += 'La pozione esplode!\r\n';
          text += hpDamageText;
          break;

        case 'SLIME GIRLS STING RAY': //SLIME GIRLS STING RAY
          text = 'MOLLY spara i suoi pungiglioni!\r\n';
          text += 'I pungiglioni colpiscono ' + target.name() + '!\r\n';
          text += hpDamageText;
          break;

        case 'SLIME GIRLS SWAP': //SLIME GIRLS SWAP
          text = 'MEDUSA fa qualcosa!\r\n';
          text += 'La tua VITA e il tuo SUCCO si scambiano!';
          break;

        case 'SLIME GIRLS CHAIN SAW': //SLIME GIRLS CHAIN SAW
          text = 'MARINA tira fuori una motosega!\r\n';
          text += hpDamageText;
          break;

      //HUMPHREY SWARM//
      case 'H SWARM ATTACK': //HUMPHREY SWARM ATTACK
        text = 'HUMPHREY cicronda e attacca ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      //HUMPHREY LARGE//
      case 'H LARGE ATTACK': //HUMPHREY LARGE ATTACK
        text = 'HUMPHREY colpisce ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      //HUMPHREY FACE//
      case 'H FACE CHOMP': //HUMPHREY FACE CHOMP
        text = 'HUMPHREY morde ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'H FACE DO NOTHING': //HUMPHREY FACE DO NOTHING
        text = 'HUMPHREY fissa ' + target.name() + '!\r\n';
        text += 'La bocca di HUMPHREY sbava incessantemente.';
        break;

      case 'H FACE HEAL': //HUMPHREY FACE HEAL
        text = 'HUMPHREY ingoia un avversario!\r\n';
        text += `HUMPHREY recupera ${Math.abs(hpDam)} di VITA!`
        break;

      //HUMPHREY UVULA//
      case 'UVULA DO NOTHING 1': //HUMPHREY UVULA DO NOTHING
        text = user.name() + ' sorride a ' + target.name() + '.\r\n';
      break;

      case 'UVULA DO NOTHING 2': //HUMPHREY UVULA DO NOTHING
      text = user.name() + ' fa un sorrisetto a ' + target.name() + '.\r\n';
      break;

      case 'UVULA DO NOTHING 3': //HUMPHREY UVULA DO NOTHING
      text = user.name() + ' sputa su ' + target.name() + '.\r\n';
      break;

      case 'UVULA DO NOTHING 4': //HUMPHREY UVULA DO NOTHING
      text = user.name() + ' fissa ' + target.name() + '.\r\n';
      break;

      case 'UVULA DO NOTHING 5': //HUMPHREY UVULA DO NOTHING
      text = user.name() + " fa l'occhiolino a " + target.name() + '.\r\n';
      break;

      //FEAR OF FALLING//
      case 'DARK NOTHING': //SOMETHING IN THE DARK NOTHING
        text = user.name() + ' provoca ' + target.name() + '\r\n';
        text += 'mentre cade.';
        break;

      case 'DARK ATTACK': //SOMETHING IN THE DARK ATTACK
        text = user.name() + ' spinge ' + target.name() + '.\r\n';
        text += hpDamageText;
        break;

      //FEAR OF BUGS//
      case 'BUGS ATTACK': //FEAR OF BUGS ATTACK
        text = user.name() + ' morde ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'BUGS NOTHING': //FEAR OF BUGS NOTHING
        text = user.name() + ' sta cercando di parlarti...';
        break;

      case 'SUMMON BABY SPIDER': //SUMMON BABY SPIDER
        text = 'Un uovo di ragno si schiude\r\n';
        text += 'È apparso un piccolo ragnetto.';
        break;

      case 'BUGS SPIDER WEBS': //FEAR OF BUGS SPIDER WEBS
        text = user.name() + ' intrappola ' + target.name() + '\r\n';
        text += 'in ragnatele appiccicose.\r\n';
        text += "La VELOCITÀ di " + target.name() + ' cala!';
        break;

      //BABY SPIDER//
      case 'BABY SPIDER ATTACK': //BABY SPIDER ATTACK
        text = user.name() + ' morde ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'BABY SPIDER NOTHING': //BABY SPIDER NOTHING
        text = user.name() + ' fa uno strano verso.';
        break;

      //FEAR OF DROWNING//
      case 'DROWNING ATTACK': //FEAR OF DROWNING ATTACK
        text = "L'acqua trascina " + target.name() + ' in diverse\r\n';
        text += 'direzioni.\r\n';
        text += hpDamageText;
        break;

      case 'DROWNING NOTHING': //FEAR OF DROWNING NOTHING
        text = user.name() + ' ascolta gli sforzi di ' + target.name();
        break;

      case 'DROWNING DRAG DOWN': //FEAR OF DROWNING DRAG DOWN
        // text = user.name() + ' prende\r\n';
        // text += ' le gambe di ' + target.name() + e lo tira giù!\r\n';
        text = hpDamageText;
        break;

      //OMORI'S SOMETHING//
      case 'O SOMETHING ATTACK': //OMORI SOMETHING ATTACK
        text = user.name() + ' si allunga verso ' + target.name() + '.\r\n';
        text += hpDamageText;
        break;

      case 'O SOMETHING NOTHING': //OMORI SOMETHING NOTHING
        text = user.name() + ' guarda attraverso ' + target.name() + '.\r\n';
        break;

      case 'O SOMETHING BLACK SPACE': //OMORI SOMETHING BLACK SPACE
        //text = user.name() + ' trascina ' + target.name() + ' nelle\r\n';
        //text += 'tenebre.';
        text = hpDamageText;
        break;

      case 'O SOMETHING SUMMON': //OMORI SOMETHING SUMMON SOMETHING
        text = user.name() + ' richiama qualcosa\r\n';
        text += "dall'oscurità.";
        break;

      case 'O SOMETHING RANDOM EMOTION': //OMORI SOMETHING RANDOM EMOTION
        text = user.name() + ' gioca con le EMOZIONI di ' + target.name() +'.';
        break;

      //BLURRY IMAGE//
      case 'BLURRY NOTHING': //BLURRY IMAGE NOTHING
        text = 'QUALCOSA fluttua nel vento.';
        break;

      //HANGING BODY//
      case 'HANG WARNING':
          text = 'Senti un brivido correre lungo la tua schiena.';
          break;

      case 'HANG NOTHING 1':
          text = 'Ti senti stordito.';
          break;

      case 'HANG NOTHING 2':
          text = 'Senti i tuoi polmoni stringersi.';
          break;

      case 'HANG NOTHING 3':
          text = 'Senti come se il tuo stomaco stesse\r\n';
          text += 'sprofondando.';
          break;

      case 'HANG NOTHING 4':
          text = 'Senti il cuore battere fuori\n';
          text += 'dal tuo petto.';
          break;

      case 'HANG NOTHING 5':
          text = 'Ti senti tremare.';
          break;

      case 'HANG NOTHING 6':
          text = 'Senti le tuoe ginocchia cedere';
          break;

      case 'HANG NOTHING 7':
          text = 'Senti il sudore gocciolare sulla tua\r\n';
          text += 'fronte.';
          break;

      case 'HANG NOTHING 8':
          text = 'Senti i tuoi pugni stringersi da soli.';
          break;

      case 'HANG NOTHING 9':
          text = 'Senti il tuo cuore battere.';
          break;

      case 'HANG NOTHING 10':
          text = 'Senti che il tuo battito inizia a stabilizzarsi.';
          break;

      case 'HANG NOTHING 11':
          text = 'Senti che il tuo respiro inizia a stabilizzarsi.';
          break;

      case 'HANG NOTHING 12':
          text = 'Ti concentri su ciò che vedi\r\n';
          text += 'davanti a te.';
          break;

      //AUBREY//
      case 'AUBREY NOTHING': //AUBREY NOTHING
        text = user.name() + ' sputa sulla tua scarpa.';
        break;

      case 'AUBREY TAUNT': //AUBREY TAUNT
        text = user.name() + ' dice a ' + target.name() + ' che è un debole!\r\n';
        text += target.name() + " si ARRABBIA!";
        break;

      //THE HOOLIGANS//
      case 'CHARLIE ATTACK': //HOOLIGANS CHARLIE ATTACK
        text = 'CHARLIE mette tutto se stesso in un attacco!\r\n';
        text += hpDamageText;
        break;

      case 'ANGEL ATTACK': //HOOLIGANS ANGEL ATTACK
        text = 'ANGEL colpisce rapidamente ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'MAVERICK CHARM': //HOOLIGANS MAVERICK CHARM
        text = "IL DISSIDENTE fa l'occhiolino a " + target.name() + '!\r\n';
        text += "L'ATTACCO di " + target.name() + ' cala.';
        break;

      case 'KIM HEADBUTT': //HOOLIGANS KIM HEADBUTT
        text = 'KIM da una testata a ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'VANCE CANDY': //HOOLIGANS VANCE CANDY
        text = 'VANCE lancia caramelle!\r\n';
        text += hpDamageText;
        break;

      case 'HOOLIGANS GROUP ATTACK': //THE HOOLIGANS GROUP ATTACK
        text = user.name() + ' si impegnano al massimo!\r\n';
        text += hpDamageText;
        break;

      //BASIL//
      case 'BASIL ATTACK': //BASIL ATTACK
        text = user.name() + ' raggiunge ' + target.name() + '.\r\n';
        text += hpDamageText;
        break;

      case 'BASIL NOTHING': //BASIL NOTHING
        text = 'Gli occhi di ' + user.name() + ' sono rossi per le lacrime.';
        break;

      case 'BASIL PREMPTIVE STRIKE': //BASIL PREMPTIVE STRIKE
        text = user.name() + ' ferisce il braccio di ' + target.name() + '.\r\n';
        text += hpDamageText;
        break;

      //BASIL'S SOMETHING//
      case 'B SOMETHING ATTACK': //BASIL'S SOMETHING ATTACK
        text = user.name() + ' strangola ' + target.name() + '.\r\n';
        text += hpDamageText;
        break;

      case 'B SOMETHING TAUNT': //BASIL'S SOMETHING TAUNT BASIL
        text = user.name() + ' guarda con disprezzo ' + target.name() + '.\r\n';
        break;

      //PLAYER SOMETHING BASIL FIGHT//
      case 'B PLAYER SOMETHING STRESS': //B PLAYER SOMETHING STRESS
        text = user.name() + ' fà qualcosa a\r\n';
        text += target.name() + '.\r\n';
        text += hpDamageText;
        break;

      case 'B PLAYER SOMETHING HEAL': //B PLAYER SOMETHING HEAL
        text = user.name() + ' penetra nelle ferite di ' + target.name() + '.\r\n';
        text += hpDamageText;
        break;

      case 'B OMORI SOMETHING CONSUME EMOTION': //B OMORI SOMETHING CONSUME EMOTION
        text = user.name() + ' consuma le EMOZIONI di ' + target.name() + '.';
        break;

      //CHARLIE//
      case 'CHARLIE RELUCTANT ATTACK': //CHARLIE RELUCTANT ATTACK
        text = user.name() + ' tira un pugno\r\na ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'CHARLIE NOTHING': //CHARLIE NOTHING
        text = user.name() + ' è fermo in piedi.';
        break;

      case 'CHARLIE LEAVE': //CHARLIE LEAVE
        text = user.name() + ' smette di combattere.';
        break;

      //ANGEL//
      case 'ANGEL ATTACK': //ANGEL ATTACK
        text = user.name() + ' calcia rapidamente ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'ANGEL NOTHING': //ANGEL NOTHING
        text = user.name() + ' fa un salto e si mette in posa!';
        break;

      case 'ANGEL QUICK ATTACK': //ANGEL QUICK ATTACK
        text = user.name() + ' si teletrasporta dietro a ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'ANGEL TEASE': //ANGEL TEASE
        text = user.name() + ' insulta ' + target.name() + '!';
        break;

      //THE MAVERICK//
      case 'MAVERICK ATTACK': //THE MAVERICK ATTACK
        text = user.name() + ' colpisce ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'MAVERICK NOTHING': //THE MAVERICK NOTHING
        text = user.name() + ' inizia a vantarsi\r\n';
        text += 'delle sue fan adoranti!';
        break;

      case 'MAVERICK SMILE': //THE MAVERICK SMILE
        text = user.name() + ' sorride in modo seducente!\r\n';
        text += "L'ATTACCO di " + target.name() + ' cala.';
        break;

      case 'MAVERICK TAUNT': //THE MAVERICK TAUNT
        text = user.name() + ' inizia a prendere in giro\r\n';
        text += target.name() + '!\r\n';
        text += target.name() + " si ARRABBIA!"
        break;

      //KIM//
      case 'KIM ATTACK': //KIM ATTACK
        text = user.name() + ' tira un pugno\r\na ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'KIM NOTHING': //KIM DO NOTHING
        text = ' Il telefono di ' + user.name() + 'squilla...\r\n';
        text += 'Qualcuno aveva sbagliato numero.';
        break;

      case 'KIM SMASH': //KIM SMASH
        text = user.name() + ' afferra la maglietta di ' + target.name() + ' e\r\n';
        text += 'lo prende a pugni in faccia!\r\n';
        text += hpDamageText;
        break;

      case 'KIM TAUNT': //KIM TAUNT
        text = user.name() + ' comincia a prendere in giro ' + target.name() + '!\r\n';
        text += target.name() + " diventa TRISTE.";
        break;

      //VANCE//
      case 'VANCE ATTACK': //VANCE ATTACK
        text = user.name() + ' tira un pugno\r\na ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'VANCE NOTHING': //VANCE NOTHING
        text = user.name() + ' si gratta la pancia.';
        break;

      case 'VANCE CANDY': //VANCE CANDY
        text = user.name() + ' lancia caramelle vecchie a\r\n';
        text += target.name() + '!\r\n';
        text += 'Ewww... Sono appiccicose...\r\n';
        text += hpDamageText;
        break;

      case 'VANCE TEASE': //VANCE TEASE
        text = user.name() + ' dice cattiverie su\r\n'; 
        text += target.name() + '!\r\n';
        text += target.name() + " diventa TRISTE."
        break;

      //JACKSON//
      case 'JACKSON WALK SLOWLY': //JACKSON WALK SLOWLY
        text = user.name() + ' si avvicina lentamente...\r\n';
        text += 'Senti di non poter scappare!';
        break;

      case 'JACKSON KILL': //JACKSON AUTO KILL
        text = user.name() + ' TI HA CATTURATO!!!\r\n';
        text += 'La tua vita ti scorre davanti agli occhi!';
        break;

      //RECYCLEPATH//
      case 'R PATH ATTACK': //RECYCLEPATH ATTACK
        text = user.name() + ' colpisce ' + target.name() + ' con una busta!\r\n';
        text += hpDamageText;
        break;

      case 'R PATH SUMMON MINION': //RECYCLEPATH SUMMON MINION
        text = user.name() + ' chiama un seguace!\r\n';
        text += 'Appare un RICICULTISTA!';
        break;

      case 'R PATH FLING TRASH': //RECYCLEPATH FLING TRASH
        text = user.name() + ' lanciano tutta la loro SPAZZATURA\r\n';
        text += 'a ' + target.name() + '!\r\n'
        text += hpDamageText;
        break;

      case 'R PATH GATHER TRASH': //RECYCLEPATH GATHER TRASH
        text = user.name() + ' tira su da terra della SPAZZATURA!';
        break;

    //SOMETHING IN THE CLOSET//
      case 'CLOSET ATTACK': //SOMETHING IN THE CLOSET ATTACK
        text = user.name() + ' trascina ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'CLOSET NOTHING': //SOMETHING IN THE CLOSET DO NOTHING
        text = user.name() + ' borbotta in modo pauroso.';
        break;

      case 'CLOSET MAKE AFRAID': //SOMETHING IN THE CLOSET MAKE AFRAID
        text = user.name() + ' conosce il tuo segreto!';
        break;

      case 'CLOSET MAKE WEAK': //SOMETHING IN THE CLOSET MAKE WEAK
        text = user.name() + ' risucchia la volonta\r\ndi vivere di ' + target.name() + '!';
        break;

    //BIG STRONG TREE//
      case 'BST SWAY': //BIG STRONG TREE NOTHING 1
        text = 'Una leggera brezza soffia tra le foglie.';
        break;

      case 'BST NOTHING': //BIG STRONG TREE NOTHING 2
        text = user.name() + ' resta irremovibile\r\n';
        text += 'perché è un albero.';
        break;

    //DREAMWORLD FEAR EXTRA BATTLES//
    //HEIGHTS//
    case 'DREAM HEIGHTS ATTACK': //DREAM FEAR OF HEIGHTS ATTACK
      text = user.name() + ' colpisce ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    case 'DREAM HEIGHTS GRAB': //DREAM FEAR OF HEIGHTS GRAB
      if(target.index() <= unitLowestIndex) {
        text = 'Delle mani appaiono e afferrano tutti!\r\n';
        text += "L'ATTACCO" + 'di tutti cala!';
      }

      break;

    case 'DREAM HEIGHTS HANDS': //DREAM FEAR OF HEIGHTS HANDS
      text = 'Appaiono ancora più mani e circondano\r\n';
      text += user.name() + '.\r\n';
      if(!target._noStateMessage) {text += "La DIFESA di " + target.name() + ' aumenta!';}
      else {text += parseNoStateChange(user.name(), "LA DIFESA", "più alta!")}
      break;

    case 'DREAM HEIGHTS SHOVE': //DREAM FEAR OF HEIGHTS SHOVE
      text = user.name() + ' spinge ' + target.name() + '.\r\n';
      text += hpDamageText + '\r\n';
      if(!target._noEffectMessage && target.name() !== "OMORI"){text += target.name() + ' si IMPAURISCE.';}
      else {text += parseNoEffectEmotion(target.name(), "AFRAID")}
      break;

    case 'DREAM HEIGHTS RELEASE ANGER': //DREAM FEAR OF HEIGHTS RELEASE ANGER
      text = user.name() + ' sfoga la sua RABBIA su tutti!';
      break;

    //SPIDERS//
    case 'DREAM SPIDERS CONSUME': //DREAM FEAR OF SPIDERS CONSUME
      text = user.name() + ' intrappola e mangia ' + target.name() + '.\r\n';
      text += hpDamageText;
      break;

    //DROWNING//
    case 'DREAM DROWNING SMALL': //DREAM FEAR OF DROWNING SMALL
      text = 'Tutti fanno fatica a respirare.';
      break;

    case 'DREAM DROWNING BIG': //DREAM FEAR OF DROWNING BIG
      text = 'Tutti si sentono svenire.';
      break;

    // BLACK SPACE EXTRA //
    case 'BS LIAR': // BLACK SPACE LIAR
      text = 'Bugiardo.';
      break;

    //BACKGROUND ACTORS//
    //BERLY//
      case 'BERLY ATTACK': //BERLY ATTACK
        text = 'BERLY dà una testata\r\na ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'BERLY NOTHING 1': //BERLY NOTHING 1
        text = 'BERLY si nasconde coraggiosamente nell\'angolino.';
        break;

      case 'BERLY NOTHING 2': //BERLY NOTHING 2
        text = 'BERLY sistema i suoi occhiali.';
        break;

      //TOYS//
      case 'CAN':  // CAN
        text = user.name() + ' calcia il BARATTOLO.';
        break;

      case 'DANDELION':  // DANDELION
        text = user.name() + ' soffia sul DENTE DI LEONE.\r\n';
        text += user.name() + ' si sente di nuovo sé ' + (switches.value(6) ? 'stessa' : 'stesso');
        break;

      case 'DYNAMITE':  // DYNAMITE
        text = user.name() + ' lancia della DINAMITE!';
        break;

      case 'LIFE JAM':  // LIFE JAM
        text = user.name() + ' usa LIFE JAM su un TOAST!\r\n';
        text += 'Il TOAST diventa ' + target.name() + '!';
        break;

      case 'PRESENT':  // PRESENT
        text = target.name() + ' apre il REGALO\r\n';
        text += 'Non è quello che voleva ' + target.name() + '...\r\n';
        if(!target._noEffectMessage){text += target.name() + ' si ARRABBIA! ';}
        else {text += parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
        break;

      case 'SILLY STRING':  // DYNAMITE
        if(target.index() <= unitLowestIndex) {
          text = user.name() + ' usa STELLE FILANTI!\r\n';
          text += 'WOOOOO!! Dov\è la festa?!\r\n';
          text += 'Tutti diventano FELICI! ';
        }
        break;

      case 'SPARKLER':  // SPARKLER
        text = user.name() + ' accende la STELLINA!\r\n';
        text += 'WOOOOO!! Dov\è la festa?!\r\n';
        if(!target._noEffectMessage){text += target.name() + ' diventa FELICE!';}
        else {text += parseNoEffectEmotion(target.name(), "più FELICE")}
        break;

      case 'COFFEE': // COFFEE
        text = user.name() + ' beve un CAFFÈ...\r\n';
        text += user.name() + ' si sente benissimo!';
        break;

      case 'RUBBERBAND': // RUBBERBAND
        text = user.name() + ' frusta ' + target.name() + '!\r\n';
        text += hpDamageText;
        break;

      //OMORI BATTLE//

      case "OMORI ERASES":
        text = user.name() + " cancella il nemico.\r\n";
        text += hpDamageText;
        break;

      case "MARI ATTACK":
        text = user.name() + " cancella il nemico.\r\n";
        text += target.name() + " si IMPAURISCE.\r\n";
        text += hpDamageText;
        break;

      //STATES//
      case 'HAPPY':
        if(!target._noEffectMessage){text = target.name() + ' diventa FELICE!';}
        else {text = parseNoEffectEmotion(target.name(), "più FELICE")}
        break;

      case 'ECSTATIC':
        if(!target._noEffectMessage){text = target.name() + ' è in preda all\'ESTASI!!';}
        else {text = parseNoEffectEmotion(target.name(), "più FELICE")}
        break;

      case 'MANIC':
        if(!target._noEffectMessage){text = target.name() + ' è in preda alla MANIA!!!';}
        else {text = parseNoEffectEmotion(target.name(), "più FELICE")}
        break;

      case 'SAD':
        if(!target._noEffectMessage){text = target.name() + ' diventa TRISTE.';}
        else {text = parseNoEffectEmotion(target.name(), "più TRISTE")}
        break;

      case 'DEPRESSED':
        if(!target._noEffectMessage){text = target.name() + ' è in preda alla DEPRESSIONE..';}
        else {text = parseNoEffectEmotion(target.name(), "più TRISTE")}
        break;

      case 'MISERABLE':
        if(!target._noEffectMessage){text = target.name() + ' è in preda alla MISERIA...';}
        else {text = parseNoEffectEmotion(target.name(), "più TRISTE")}
        break;

      case 'ANGRY':
        if(!target._noEffectMessage){text = target.name() + ' si ARRABBIA!';}
        else {text = parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
        break;

      case 'ENRAGED':
        if(!target._noEffectMessage){text = target.name() + ' si INFURIA!!';}
        else {text = parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
        break;

      case 'FURIOUS':
        if(!target._noEffectMessage){text = target.name() + ' è in preda all\'IRA!!!'}
        else {text = parseNoEffectEmotion(target.name(), "più ARRABBIATO/A")}
        break;

      case 'AFRAID':
        if(!target._noEffectMessage){text = target.name() + ' si IMPAURISCE!';}
        else {text = parseNoEffectEmotion(target.name(), "AFRAID")}
        break;

      case 'CANNOT MOVE':
        text = target.name() + ' è immobilizzato! ';
        break;

      case 'INFATUATION':
        text = target.name() + ' è immobilizzato dall\'amore! ';
        break;



  }
  // Return Text
  return text;
};
//=============================================================================
// * Display Custom Action Text
//=============================================================================
Window_BattleLog.prototype.displayCustomActionText = function(subject, target, item) {
  // Make Custom Action Text
  var text = this.makeCustomActionText(subject, target, item);
  // If Text Length is more than 0
  if (text.length > 0) {
    if(!!this._multiHitFlag && !!item.isRepeatingSkill) {return;}
    // Get Get
    text = text.split(/\r\n/);
    for (var i = 0; i < text.length; i++) { this.push('addText', text[i]); }
    // Add Wait
    this.push('wait', 15);

  }
  if(!!item.isRepeatingSkill) {this._multiHitFlag = true;}
};
//=============================================================================
// * Display Action
//=============================================================================
Window_BattleLog.prototype.displayAction = function(subject, item) {
  // Return if Item has Custom Battle Log Type
  if (item.meta.BattleLogType) { return; }
  // Run Original Function
  _TDS_.CustomBattleActionText.Window_BattleLog_displayAction.call(this, subject, item);
};
//=============================================================================
// * Display Action Results
//=============================================================================
Window_BattleLog.prototype.displayActionResults = function(subject, target) {
  // Get Item Object
  var item = BattleManager._action._item.object();
  // If Item has custom battle log type
  if (item && item.meta.BattleLogType) {
    // Display Custom Action Text
    this.displayCustomActionText(subject, target, item);
    // Return
  }
  // Run Original Function
  else {
    _TDS_.CustomBattleActionText.Window_BattleLog_displayActionResults.call(this, subject, target);
  }
};

const _old_window_battleLog_displayHpDamage = Window_BattleLog.prototype.displayHpDamage
Window_BattleLog.prototype.displayHpDamage = function(target) {
  let result = target.result();
  if(result.isHit() && result.hpDamage > 0) {
    if(!!result.elementStrong) {
      this.push("addText","...Bel colpo!");
      this.push("waitForNewLine");
    }
    else if(!!result.elementWeak) {
      this.push("addText", "...Colpo fiacco!");
      this.push("waitForNewLine")
    }
  }
  return _old_window_battleLog_displayHpDamage.call(this, target)
};

//=============================================================================
// * CLEAR
//=============================================================================
_TDS_.CustomBattleActionText.Window_BattleLog_endAction= Window_BattleLog.prototype.endAction;
Window_BattleLog.prototype.endAction = function() {
  _TDS_.CustomBattleActionText.Window_BattleLog_endAction.call(this);
  this._multiHitFlag = false;
};

//=============================================================================
// * DISPLAY ADDED STATES
//=============================================================================
